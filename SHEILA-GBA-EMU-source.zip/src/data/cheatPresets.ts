import { CheatFormat } from '../types';

export interface CheatPresetItem {
  name: string;
  code: string;
  format: CheatFormat;
  description: string;
}

export interface GameCheatPresets {
  gameTitle: string;
  gameIdMatch?: string[]; // Match game IDs or titles
  cheats: CheatPresetItem[];
}

export const CHEAT_PRESETS: GameCheatPresets[] = [
  {
    gameTitle: 'Frogtris GBA (Preloaded Homebrew)',
    gameIdMatch: ['homebrew-frogtris', 'frogtris'],
    cheats: [
      {
        name: 'Slow Fall Speed (Easy Mode)',
        code: '02001A40 00000001',
        format: 'ActionReplay',
        description: 'Locks the drop rate to level 1 for casual, relaxed puzzle solving.',
      },
      {
        name: 'Max Score Boost (999,999)',
        code: '02001B20 000F423F',
        format: 'ActionReplay',
        description: 'Instantly sets high score register to maximum digits.',
      },
      {
        name: 'Freeze Game Over Line',
        code: '02001C10 00000000',
        format: 'ActionReplay',
        description: 'Prevents automatic top-out game over condition.',
      },
    ],
  },
  {
    gameTitle: 'Gapman Arcade (Preloaded Homebrew)',
    gameIdMatch: ['homebrew-gapman', 'gapman'],
    cheats: [
      {
        name: 'Infinite Lives (99)',
        code: '02002100 00000063',
        format: 'ActionReplay',
        description: 'Sets player lives counter to 99 remaining.',
      },
      {
        name: 'Freeze Maze Patrols',
        code: '02002150 00000000',
        format: 'ActionReplay',
        description: 'Stops enemy movement while allowing player to freely collect pellets.',
      },
      {
        name: 'Score Multiplier 10x',
        code: '02002200 0000000A',
        format: 'ActionReplay',
        description: 'Multiplies dot pickup scores by 10x.',
      },
    ],
  },
  {
    gameTitle: 'Impact Space Shooter (Preloaded Homebrew)',
    gameIdMatch: ['homebrew-impact', 'impact'],
    cheats: [
      {
        name: 'Infinite Shield / Health',
        code: '02003884 000003E7',
        format: 'ActionReplay',
        description: 'Locks ship hull integrity to 999 HP.',
      },
      {
        name: 'Rapid Fire Cannons',
        code: '02003890 00000000',
        format: 'ActionReplay',
        description: 'Removes shot cooldown timer for continuous laser stream.',
      },
      {
        name: 'Infinite Super Bombs',
        code: '020038A4 00000009',
        format: 'ActionReplay',
        description: 'Screen-clearing smart bombs never deplete.',
      },
    ],
  },
  {
    gameTitle: 'Pokémon Emerald',
    gameIdMatch: ['emerald', 'pokemon emerald', 'bpee'],
    cheats: [
      {
        name: 'Master Code (Must Be On)',
        code: 'D8BAE4D9 4864DCE5\nA86C21C7 AE103484',
        format: 'ActionReplay',
        description: 'Required hook to enable Action Replay v3 memory rewriting.',
      },
      {
        name: 'Infinite Money ($999,999)',
        code: 'D8BAE4D9 4864DCE5\n82003884 03E7',
        format: 'ActionReplay',
        description: 'Sets trainer wallet to maximum allowable money.',
      },
      {
        name: 'Unlimited Rare Candies (PC Slot 1)',
        code: '82005274 0044',
        format: 'ActionReplay',
        description: 'Withdraw 99 Rare Candies from first slot of PC Item Storage.',
      },
      {
        name: 'Unlimited Master Balls (PC Slot 1)',
        code: '82005274 0001',
        format: 'ActionReplay',
        description: 'Withdraw unlimited 100% catch rate Master Balls from PC.',
      },
      {
        name: 'Walk Through Walls (Ghost Mode)',
        code: '788101EA E8524AEC\n8E883EFF 92E9660D',
        format: 'ActionReplay',
        description: 'Bypass collision trees, fences, water tiles, and ledge obstacles.',
      },
      {
        name: '100% Wild Catch Rate',
        code: '87ACDA2A BEA0EC82\nD7785553 F6161414',
        format: 'ActionReplay',
        description: 'Any Poké Ball thrown guarantees instant capture.',
      },
    ],
  },
  {
    gameTitle: 'Pokémon FireRed / LeafGreen',
    gameIdMatch: ['firered', 'leafgreen', 'bpre', 'bpgf', 'pokemon firered'],
    cheats: [
      {
        name: 'Master Code (Must Be On)',
        code: '72BC6DFB E9CA5465\nA472A448 E3A10926',
        format: 'ActionReplay',
        description: 'Required hook for FireRed / LeafGreen AR codes.',
      },
      {
        name: 'Infinite Money ($999,999)',
        code: '82003884 0F42\n82003886 003F',
        format: 'ActionReplay',
        description: 'Gives maximum money in the trainer card.',
      },
      {
        name: 'Unlimited Rare Candies (PC Item)',
        code: '82025840 0044',
        format: 'ActionReplay',
        description: 'Withdraw 99 Rare Candies from PC.',
      },
      {
        name: 'Unlimited Master Balls (PC Item)',
        code: '82025840 0001',
        format: 'ActionReplay',
        description: 'Withdraw 99 Master Balls from PC item storage.',
      },
      {
        name: 'Walk Through Walls (Toggle)',
        code: '509197D3 542975F4\n78DA6220 740B7E82',
        format: 'ActionReplay',
        description: 'No clipping across maps and gym barriers.',
      },
    ],
  },
  {
    gameTitle: 'The Legend of Zelda: The Minish Cap',
    gameIdMatch: ['minish', 'zelda', 'bzme'],
    cheats: [
      {
        name: 'Infinite Hearts / Invincible',
        code: '02002AEA 00000050',
        format: 'ActionReplay',
        description: 'Locks Link to full health hearts permanently.',
      },
      {
        name: 'Max Rupees (999)',
        code: '02002AE8 000003E7',
        format: 'ActionReplay',
        description: 'Fill wallet with 999 rupees.',
      },
      {
        name: 'Infinite Bombs & Arrows (99)',
        code: '02002AF2 00006363',
        format: 'ActionReplay',
        description: 'Never run out of ammunition during dungeon puzzles.',
      },
      {
        name: 'Max Kinstone Bag',
        code: '02002B00 0000FFFF',
        format: 'ActionReplay',
        description: 'Unlock all rare fusion Kinstone pieces.',
      },
    ],
  },
  {
    gameTitle: 'Super Mario Advance 4: Super Mario Bros 3',
    gameIdMatch: ['mario', 'super mario advance', 'ax4e'],
    cheats: [
      {
        name: 'Infinite Lives (99 Lives)',
        code: '02000078 00000063',
        format: 'ActionReplay',
        description: 'Never encounter Game Over screens.',
      },
      {
        name: 'Permanent Invincibility (Star Power)',
        code: '0200053E 000000FF',
        format: 'ActionReplay',
        description: 'Run through all enemy hazards with infinite star power.',
      },
      {
        name: 'Always Tanooki Suit',
        code: '02000074 00000005',
        format: 'ActionReplay',
        description: 'Fly anywhere and turn into statue stone.',
      },
      {
        name: 'Freeze Stage Timer',
        code: '02000072 000003E7',
        format: 'ActionReplay',
        description: 'Timer remains locked at 999 seconds.',
      },
    ],
  },
  {
    gameTitle: 'Metroid Fusion',
    gameIdMatch: ['metroid', 'fusion', 'amfe'],
    cheats: [
      {
        name: 'Infinite Energy / Health',
        code: '02038750 000003E7',
        format: 'ActionReplay',
        description: 'Lock Samus Energy tanks to 999 maximum.',
      },
      {
        name: 'Infinite Missiles (999)',
        code: '02038758 000003E7',
        format: 'ActionReplay',
        description: 'Unlimited standard, super, and diffusion missiles.',
      },
      {
        name: 'Infinite Power Bombs',
        code: '0203875C 00000063',
        format: 'ActionReplay',
        description: 'Keep 99 Power Bombs ready at all times.',
      },
    ],
  },
  {
    gameTitle: 'Castlevania: Aria of Sorrow',
    gameIdMatch: ['castlevania', 'aria', 'aane'],
    cheats: [
      {
        name: 'Infinite HP',
        code: '02013280 0000270F',
        format: 'ActionReplay',
        description: 'Locks Soma Cruz health to 9999 HP.',
      },
      {
        name: 'Infinite MP',
        code: '02013284 0000270F',
        format: 'ActionReplay',
        description: 'Cast all tactical and guardian souls without depleting magic.',
      },
      {
        name: 'Max Gold (999,999)',
        code: '0201328C 000F423F',
        format: 'ActionReplay',
        description: 'Purchase any weapon, armor, and accessory from Hammer.',
      },
      {
        name: '100% Soul Drop Rate',
        code: '02013290 000003E7',
        format: 'ActionReplay',
        description: 'Every enemy defeated immediately drops their monster soul.',
      },
    ],
  },
];
