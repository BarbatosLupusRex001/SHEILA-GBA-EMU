export type EmulatorStatus = 'idle' | 'loading' | 'running' | 'paused' | 'error';

export interface EmulatorStats {
  fps: number;
  speedMultiplier: number;
  status: EmulatorStatus;
  gameTitle: string;
}

export class GBAEmulatorService {
  private playerIframe: HTMLIFrameElement | null = null;
  private currentBuffer: ArrayBuffer | null = null;
  private currentTitle: string = '';
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private fastForward: boolean = false;
  private fastForwardMultiplier: number = 2;
  private currentFps: number = 60;
  private onStatsCallback?: (stats: EmulatorStats) => void;
  private onErrorCallback?: (err: string) => void;

  constructor() {
    this.handleWindowMessage = this.handleWindowMessage.bind(this);
    if (typeof window !== 'undefined') {
      window.addEventListener('message', this.handleWindowMessage);
    }
  }

  public setPlayerIframe(iframe: HTMLIFrameElement | null): void {
    this.playerIframe = iframe;
    if (iframe && this.currentBuffer) {
      this.sendToPlayer({
        action: 'LOAD_ROM_BUFFER',
        buffer: this.currentBuffer,
        title: this.currentTitle,
      });
    }
  }

  private handleWindowMessage(event: MessageEvent): void {
    if (!event.data || event.data.source !== 'SHEILA_GBA') return;
    const { type, payload } = event.data;

    switch (type) {
      case 'PLAYER_READY':
        if (this.currentBuffer) {
          this.sendToPlayer({
            action: 'LOAD_ROM_BUFFER',
            buffer: this.currentBuffer,
            title: this.currentTitle,
          });
        }
        break;

      case 'GAME_STARTED':
        this.isRunning = true;
        this.isPaused = false;
        this.currentFps = 60;
        this.notifyStats();
        break;

      case 'GAME_PAUSED':
        this.isPaused = true;
        this.notifyStats();
        break;

      case 'GAME_RESUMED':
        this.isPaused = false;
        this.notifyStats();
        break;

      case 'FAST_FORWARD_SET':
        this.fastForwardMultiplier = payload?.speed || 2;
        this.fastForward = this.fastForwardMultiplier > 1;
        this.notifyStats();
        break;
    }
  }

  public sendToPlayer(message: any): void {
    try {
      if (this.playerIframe && this.playerIframe.contentWindow) {
        this.playerIframe.contentWindow.postMessage(
          { target: 'SHEILA_PLAYER', ...message },
          '*'
        );
      }
    } catch (err) {
      console.warn('[GBA Service] Failed to send message to player:', err);
    }
  }

  public init(element?: any): boolean {
    this.isRunning = false;
    this.isPaused = false;
    this.notifyStats();
    return true;
  }

  public async loadRom(buffer: ArrayBuffer, title: string = 'Game'): Promise<boolean> {
    try {
      this.currentBuffer = buffer;
      this.currentTitle = title;
      this.isRunning = true;
      this.isPaused = false;

      this.sendToPlayer({
        action: 'LOAD_ROM_BUFFER',
        buffer: buffer,
        title: title,
      });

      this.notifyStats();
      return true;
    } catch (err: any) {
      console.error('Failed to load ROM:', err);
      if (this.onErrorCallback) this.onErrorCallback(err.message || 'ROM loading failed');
      return false;
    }
  }

  public start(): void {
    this.isRunning = true;
    this.isPaused = false;
    this.sendToPlayer({ action: 'RESUME' });
    this.notifyStats();
  }

  public pause(): void {
    this.isPaused = true;
    this.sendToPlayer({ action: 'PAUSE' });
    this.notifyStats();
  }

  public resume(): void {
    this.isPaused = false;
    this.sendToPlayer({ action: 'RESUME' });
    this.notifyStats();
  }

  public reset(): void {
    this.sendToPlayer({ action: 'RESET' });
    this.notifyStats();
  }

  public stop(): void {
    this.isRunning = false;
    this.isPaused = false;
    this.notifyStats();
  }

  public setFastForward(enabled: boolean, multiplier: number = 2): void {
    this.fastForward = enabled;
    this.fastForwardMultiplier = enabled ? multiplier : 1;
    this.sendToPlayer({
      action: 'FAST_FORWARD',
      speed: enabled ? multiplier : 1,
    });
    this.notifyStats();
  }

  public setFrameSkip(skip: number): void {
    // Handled by mGBA core automatically
  }

  public setVolume(volume0to100: number): void {
    const clamped = Math.max(0, Math.min(1, volume0to100 / 100));
    this.sendToPlayer({ action: 'SET_VOLUME', volume: clamped });
  }

  public setMuted(muted: boolean): void {
    this.sendToPlayer({ action: 'SET_VOLUME', volume: muted ? 0 : 1 });
  }

  // Keypad controls
  public pressKey(keyName: string): void {
    this.sendToPlayer({ action: 'PRESS_KEY', key: keyName });
  }

  public releaseKey(keyName: string): void {
    this.sendToPlayer({ action: 'RELEASE_KEY', key: keyName });
  }

  public saveState(slot: number = 1, isAutoSave: boolean = false, reason?: string): void {
    this.sendToPlayer({ action: 'SAVE_STATE', slot, isAutoSave, reason });
  }

  public autoSave(reason: 'periodic' | 'exit' | 'tab_change' = 'periodic'): void {
    this.saveState(0, true, reason);
  }

  public freezeState(): any {
    this.sendToPlayer({ action: 'SAVE_STATE', slot: 1 });
    return { slot: 1, timestamp: Date.now() };
  }

  public defrostState(stateData: any): boolean {
    this.sendToPlayer({ action: 'LOAD_STATE', slot: 1, state: stateData });
    return true;
  }

  public exportBatterySave(): string | null {
    return null;
  }

  public importBatterySave(base64Data: string): boolean {
    return true;
  }

  public loadState(slot: number = 1, stateData?: any): void {
    this.sendToPlayer({ action: 'LOAD_STATE', slot, state: stateData });
  }

  public takeScreenshot(): void {
    this.sendToPlayer({ action: 'SCREENSHOT' });
  }

  public rewind(): void {
    this.sendToPlayer({ action: 'REWIND' });
  }

  public syncCheats(cheats: any[]): void {
    this.sendToPlayer({ action: 'APPLY_CHEATS', cheats });
  }

  public onStats(cb: (stats: EmulatorStats) => void): void {
    this.onStatsCallback = cb;
  }

  public onError(cb: (err: string) => void): void {
    this.onErrorCallback = cb;
  }

  private notifyStats(): void {
    if (!this.onStatsCallback) return;
    this.onStatsCallback({
      fps: this.isRunning && !this.isPaused ? 60 : 0,
      speedMultiplier: this.fastForward ? this.fastForwardMultiplier : 1,
      status: !this.isRunning ? 'idle' : this.isPaused ? 'paused' : 'running',
      gameTitle: this.currentTitle,
    });
  }
}

export const emulatorInstance = new GBAEmulatorService();
