import React, { useState, useMemo } from 'react';
import { Game, Cheat, CheatFormat } from '../types';
import { validateCheatCode } from '../utils/cheatValidator';
import { CHEAT_PRESETS, CheatPresetItem } from '../data/cheatPresets';
import {
  Wand2,
  Plus,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Edit3,
  Search,
  BookOpen,
  Download,
  Upload,
  Power,
  PowerOff,
  Copy,
  Check,
  Sparkles,
  Gamepad2,
  RotateCcw,
} from 'lucide-react';

interface CheatsManagerProps {
  activeGame: Game | null;
  cheats: Cheat[];
  onAddCheat: (cheat: Cheat) => void;
  onUpdateCheat: (cheat: Cheat) => void;
  onToggleCheat: (id: string) => void;
  onDeleteCheat: (id: string) => void;
  onBatchAddCheats?: (cheats: Cheat[]) => void;
  onClearGameCheats?: (gameId: string) => void;
}

export const CheatsManager: React.FC<CheatsManagerProps> = ({
  activeGame,
  cheats,
  onAddCheat,
  onUpdateCheat,
  onToggleCheat,
  onDeleteCheat,
  onBatchAddCheats,
  onClearGameCheats,
}) => {
  // Modal states: 'add' | 'edit' | null
  const [modalMode, setModalMode] = useState<'add' | 'edit' | null>(null);
  const [editingCheatId, setEditingCheatId] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [format, setFormat] = useState<CheatFormat>('ActionReplay');
  const [description, setDescription] = useState('');

  // UI / View states
  const [searchQuery, setSearchQuery] = useState('');
  const [filterState, setFilterState] = useState<'all' | 'enabled' | 'disabled'>('all');
  const [showPresetsModal, setShowPresetsModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Live validator preview for form
  const validation = validateCheatCode(code, format);

  // Filter cheats for currently active game or all
  const gameCheats = useMemo(() => {
    return activeGame
      ? cheats.filter((c) => c.gameId === activeGame.id || c.gameId === 'global')
      : cheats;
  }, [cheats, activeGame]);

  const filteredCheats = useMemo(() => {
    return gameCheats.filter((c) => {
      const matchesSearch =
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.description && c.description.toLowerCase().includes(searchQuery.toLowerCase()));

      if (!matchesSearch) return false;
      if (filterState === 'enabled') return c.enabled;
      if (filterState === 'disabled') return !c.enabled;
      return true;
    });
  }, [gameCheats, searchQuery, filterState]);

  // Open modal in Add mode
  const handleOpenAddModal = () => {
    setModalMode('add');
    setEditingCheatId(null);
    setName('');
    setCode('');
    setFormat('ActionReplay');
    setDescription('');
  };

  // Open modal in Edit mode
  const handleOpenEditModal = (cheat: Cheat) => {
    setModalMode('edit');
    setEditingCheatId(cheat.id);
    setName(cheat.name);
    setCode(cheat.code);
    setFormat(cheat.format);
    setDescription(cheat.description || '');
  };

  const handleCloseModal = () => {
    setModalMode(null);
    setEditingCheatId(null);
    setName('');
    setCode('');
    setDescription('');
  };

  // Save (Create or Update)
  const handleSaveCheat = () => {
    if (!name.trim()) {
      alert('Please provide a descriptive name for this cheat.');
      return;
    }
    if (!validation.isValid) {
      alert(validation.errorMessage || 'Invalid cheat code format.');
      return;
    }

    if (modalMode === 'edit' && editingCheatId) {
      const existing = cheats.find((c) => c.id === editingCheatId);
      if (!existing) return;

      const updatedCheat: Cheat = {
        ...existing,
        name: name.trim(),
        code: validation.normalizedCode,
        format: validation.detectedFormat,
        description: description.trim() || undefined,
        status: 'ENABLED',
      };

      onUpdateCheat(updatedCheat);
      showToast(`Updated cheat: "${updatedCheat.name}"`);
    } else {
      const newCheat: Cheat = {
        id: `cheat-${Date.now()}`,
        gameId: activeGame ? activeGame.id : 'global',
        name: name.trim(),
        code: validation.normalizedCode,
        format: validation.detectedFormat,
        status: 'ENABLED',
        enabled: true,
        description: description.trim() || undefined,
      };

      onAddCheat(newCheat);
      showToast(`Added new cheat: "${newCheat.name}"`);
    }

    handleCloseModal();
  };

  // Bulk actions
  const handleToggleAll = (enable: boolean) => {
    gameCheats.forEach((c) => {
      if (c.enabled !== enable) {
        onToggleCheat(c.id);
      }
    });
    showToast(enable ? 'Enabled all cheats for current game' : 'Disabled all cheats');
  };

  const handleClearGameCheats = () => {
    if (!gameCheats.length) return;
    if (confirm(`Are you sure you want to delete all ${gameCheats.length} cheats for this game?`)) {
      if (onClearGameCheats && activeGame) {
        onClearGameCheats(activeGame.id);
      } else {
        gameCheats.forEach((c) => onDeleteCheat(c.id));
      }
      showToast('All cheats deleted for this game');
    }
  };

  // Import single preset item
  const handleImportPresetItem = (preset: CheatPresetItem) => {
    const val = validateCheatCode(preset.code, preset.format);
    const newCheat: Cheat = {
      id: `cheat-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      gameId: activeGame ? activeGame.id : 'global',
      name: preset.name,
      code: val.isValid ? val.normalizedCode : preset.code,
      format: preset.format,
      status: val.isValid ? 'ENABLED' : 'INVALID',
      enabled: true,
      description: preset.description,
    };

    onAddCheat(newCheat);
    showToast(`Imported preset: ${preset.name}`);
  };

  // Import all presets for a group
  const handleImportAllGroupPresets = (presets: CheatPresetItem[]) => {
    const newItems: Cheat[] = presets.map((p, idx) => {
      const val = validateCheatCode(p.code, p.format);
      return {
        id: `cheat-${Date.now()}-${idx}`,
        gameId: activeGame ? activeGame.id : 'global',
        name: p.name,
        code: val.isValid ? val.normalizedCode : p.code,
        format: p.format,
        status: val.isValid ? 'ENABLED' : 'INVALID',
        enabled: true,
        description: p.description,
      };
    });

    if (onBatchAddCheats) {
      onBatchAddCheats(newItems);
    } else {
      newItems.forEach((c) => onAddCheat(c));
    }
    setShowPresetsModal(false);
    showToast(`Imported ${newItems.length} preset cheats`);
  };

  // Export cheats as JSON
  const handleExportCheats = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(gameCheats, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `${activeGame ? activeGame.title.toLowerCase().replace(/[^a-z0-9]/g, '_') : 'sheila_gba'}_cheats.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Exported cheats JSON');
  };

  // Import cheats from JSON
  const handleProcessImportJson = () => {
    try {
      const parsed = JSON.parse(importJsonText);
      if (!Array.isArray(parsed)) {
        alert('Invalid JSON format. Expected an array of cheat objects.');
        return;
      }
      const importedCheats: Cheat[] = parsed.map((item, idx) => {
        const val = validateCheatCode(item.code || '', item.format);
        return {
          id: `cheat-${Date.now()}-${idx}`,
          gameId: activeGame ? activeGame.id : item.gameId || 'global',
          name: item.name || `Imported Cheat ${idx + 1}`,
          code: val.isValid ? val.normalizedCode : item.code || '',
          format: item.format || 'ActionReplay',
          status: val.isValid ? 'ENABLED' : 'INVALID',
          enabled: item.enabled !== false,
          description: item.description,
        };
      });

      if (onBatchAddCheats) {
        onBatchAddCheats(importedCheats);
      } else {
        importedCheats.forEach((c) => onAddCheat(c));
      }
      setShowImportModal(false);
      setImportJsonText('');
      showToast(`Successfully imported ${importedCheats.length} cheats`);
    } catch (err: any) {
      alert(`JSON Parse Error: ${err.message}`);
    }
  };

  const handleCopyCode = (id: string, codeToCopy: string) => {
    navigator.clipboard?.writeText(codeToCopy);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Active cheats count
  const activeCount = gameCheats.filter((c) => c.enabled).length;

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-indigo-600 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-xl border border-indigo-400 flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#1f2533] pb-5">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2.5">
            <Wand2 className="w-6 h-6 text-indigo-400" />
            <span>Cheat Engine & Code Manager</span>
            {activeGame && (
              <span className="text-xs px-2.5 py-1 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800">
                {activeGame.title}
              </span>
            )}
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Input, edit, toggle on/off, and delete Action Replay v3, GameShark, and CodeBreaker cheats anytime.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowPresetsModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#171c26] hover:bg-[#202735] text-amber-300 border border-amber-500/30 rounded-xl text-xs font-semibold transition-colors"
            title="Browse verified cheat presets for popular GBA games"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span>Cheat Presets</span>
          </button>

          <button
            onClick={() => setShowImportModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#171c26] hover:bg-[#202735] text-zinc-300 border border-[#2a3445] rounded-xl text-xs font-semibold transition-colors"
            title="Import Cheats from JSON"
          >
            <Upload className="w-3.5 h-3.5 text-zinc-400" />
            <span>Import</span>
          </button>

          {gameCheats.length > 0 && (
            <button
              onClick={handleExportCheats}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#171c26] hover:bg-[#202735] text-zinc-300 border border-[#2a3445] rounded-xl text-xs font-semibold transition-colors"
              title="Export Cheats to JSON file"
            >
              <Download className="w-3.5 h-3.5 text-zinc-400" />
              <span>Export</span>
            </button>
          )}

          <button
            onClick={handleOpenAddModal}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Cheat</span>
          </button>
        </div>
      </div>

      {/* Overview & Quick Toggle Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#11151e] border border-[#202735] rounded-2xl p-4 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-white">
              {activeCount} of {gameCheats.length} cheats active
            </span>
          </div>
          <span className="text-zinc-500">|</span>
          <span className="text-zinc-400">
            Real-time memory injection active in mGBA
          </span>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
          <button
            onClick={() => handleToggleAll(true)}
            disabled={gameCheats.length === 0}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-800/60 rounded-lg text-xs font-medium disabled:opacity-40 transition-colors"
          >
            <Power className="w-3 h-3" />
            <span>Enable All</span>
          </button>
          <button
            onClick={() => handleToggleAll(false)}
            disabled={gameCheats.length === 0}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 rounded-lg text-xs font-medium disabled:opacity-40 transition-colors"
          >
            <PowerOff className="w-3 h-3" />
            <span>Disable All</span>
          </button>
          {gameCheats.length > 0 && (
            <button
              onClick={handleClearGameCheats}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 rounded-lg text-xs font-medium transition-colors"
              title="Delete all cheats for this game"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear All</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search cheats by name, code, or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#121620] border border-[#212937] rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1 bg-[#121620] border border-[#212937] p-1 rounded-xl text-xs">
          <button
            onClick={() => setFilterState('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              filterState === 'all'
                ? 'bg-indigo-600 text-white'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            All ({gameCheats.length})
          </button>
          <button
            onClick={() => setFilterState('enabled')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              filterState === 'enabled'
                ? 'bg-emerald-600 text-white'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Active ({activeCount})
          </button>
          <button
            onClick={() => setFilterState('disabled')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              filterState === 'disabled'
                ? 'bg-zinc-700 text-white'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Off ({gameCheats.length - activeCount})
          </button>
        </div>
      </div>

      {/* Format Info Banner */}
      <div className="bg-[#11151e] border border-[#202735] rounded-2xl p-4 text-xs text-zinc-300 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-1">
          <span className="font-bold text-indigo-300">Action Replay / GameShark v3</span>
          <p className="text-zinc-400 text-[11px]">
            16 hexadecimal digits (8 + 8): <br />
            <code className="text-indigo-200 font-mono">XXXXXXXX YYYYYYYY</code>
          </p>
        </div>
        <div className="space-y-1">
          <span className="font-bold text-emerald-300">CodeBreaker</span>
          <p className="text-zinc-400 text-[11px]">
            12 hexadecimal digits (8 + 4): <br />
            <code className="text-emerald-200 font-mono">XXXXXXXX YYYY</code>
          </p>
        </div>
        <div className="space-y-1">
          <span className="font-bold text-amber-300">Live Real-Time Editing</span>
          <p className="text-zinc-400 text-[11px]">
            Edit name, format, or memory codes anytime. Changes take effect on the next CPU tick.
          </p>
        </div>
      </div>

      {/* Cheats List */}
      <div className="space-y-3">
        {filteredCheats.map((cheat) => (
          <div
            key={cheat.id}
            className={`flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-2xl border transition-all ${
              cheat.enabled
                ? 'bg-[#121620] border-indigo-500/40 shadow-sm shadow-indigo-950/30'
                : 'bg-[#0f121a] border-[#1d2330] opacity-80'
            } gap-4`}
          >
            <div className="space-y-2 flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-sm text-white truncate">{cheat.name}</span>
                <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700 uppercase">
                  {cheat.format}
                </span>

                {/* Status Badge */}
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 ${
                    !cheat.enabled
                      ? 'bg-zinc-800 text-zinc-400'
                      : cheat.status === 'ENABLED'
                      ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                      : 'bg-rose-950/80 text-rose-300 border border-rose-800/60'
                  }`}
                >
                  {!cheat.enabled ? (
                    'DISABLED'
                  ) : cheat.status === 'ENABLED' ? (
                    <>
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      <span>ENABLED</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-3 h-3 text-rose-400" />
                      <span>INVALID</span>
                    </>
                  )}
                </span>
              </div>

              {cheat.description && (
                <p className="text-xs text-zinc-400">{cheat.description}</p>
              )}

              <div className="relative group">
                <pre className="text-[11px] font-mono text-zinc-300 bg-[#090b10] px-3 py-2 rounded-lg border border-[#1b202c] overflow-x-auto whitespace-pre">
                  {cheat.code}
                </pre>
                <button
                  onClick={() => handleCopyCode(cheat.id, cheat.code)}
                  className="absolute right-2 top-2 p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded opacity-0 group-hover:opacity-100 transition-opacity text-[10px] flex items-center gap-1"
                  title="Copy code"
                >
                  {copiedId === cheat.id ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Actions: Toggle, Edit, Delete */}
            <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
              {/* On / Off Toggle */}
              <button
                onClick={() => onToggleCheat(cheat.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  cheat.enabled
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-700/20'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-400'
                }`}
                title={cheat.enabled ? 'Click to turn off cheat' : 'Click to turn on cheat'}
              >
                {cheat.enabled ? (
                  <>
                    <Power className="w-3.5 h-3.5" />
                    <span>ON</span>
                  </>
                ) : (
                  <>
                    <PowerOff className="w-3.5 h-3.5" />
                    <span>OFF</span>
                  </>
                )}
              </button>

              {/* Edit Button (Requested by User) */}
              <button
                onClick={() => handleOpenEditModal(cheat)}
                className="p-2 text-zinc-400 hover:text-indigo-400 hover:bg-indigo-950/40 border border-transparent hover:border-indigo-800/50 rounded-xl transition-colors cursor-pointer"
                title="Edit this cheat (Code, Name, Format, Notes)"
              >
                <Edit3 className="w-4 h-4" />
              </button>

              {/* Delete Button (Requested by User) */}
              <button
                onClick={() => {
                  if (confirm(`Delete cheat "${cheat.name}"?`)) {
                    onDeleteCheat(cheat.id);
                    showToast(`Deleted "${cheat.name}"`);
                  }
                }}
                className="p-2 text-zinc-500 hover:text-rose-400 hover:bg-rose-950/40 border border-transparent hover:border-rose-800/50 rounded-xl transition-colors cursor-pointer"
                title="Delete this cheat"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}

        {filteredCheats.length === 0 && (
          <div className="text-center py-12 bg-[#121620] rounded-2xl border border-[#202735] space-y-3">
            <Wand2 className="w-10 h-10 text-zinc-500 mx-auto" />
            <p className="text-sm font-semibold text-zinc-300">
              {searchQuery ? 'No cheats match your search filter' : 'No cheat codes added yet'}
            </p>
            <p className="text-xs text-zinc-500 max-w-md mx-auto">
              Add custom GameShark/ActionReplay codes, choose from our verified Presets Library, or ask SHEILA AI to find cheat codes for this game.
            </p>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setShowPresetsModal(true)}
                className="px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Browse Cheat Presets</span>
              </button>
              <button
                onClick={handleOpenAddModal}
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Code</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Add / Edit Cheat Modal */}
      {modalMode && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12151d] border border-[#242b38] rounded-2xl max-w-lg w-full p-5 shadow-2xl space-y-4 text-white">
            <div className="flex items-center justify-between border-b border-[#212734] pb-3">
              <div className="flex items-center gap-2">
                <Wand2 className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold">
                  {modalMode === 'edit' ? 'Edit Cheat Code' : 'Add New Cheat Code'}
                </h3>
              </div>
              <button
                onClick={handleCloseModal}
                className="text-zinc-400 hover:text-white text-xs px-2.5 py-1 bg-zinc-800 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-zinc-300 font-medium mb-1">
                  Cheat Description / Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Infinite Lives, Max Gold, Walk Through Walls, 100% Catch Rate"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#181d27] border border-[#262e3d] rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-zinc-300 font-medium mb-1">Cheat Engine Format</label>
                <select
                  value={format}
                  onChange={(e) => setFormat(e.target.value as CheatFormat)}
                  className="w-full px-3 py-2 bg-[#181d27] border border-[#262e3d] rounded-xl text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="ActionReplay">Action Replay v3 (16-Digit: XXXXXXXX YYYYYYYY)</option>
                  <option value="GameShark">GameShark GBA (16-Digit: XXXXXXXX YYYYYYYY)</option>
                  <option value="CodeBreaker">CodeBreaker (12-Digit: XXXXXXXX YYYY)</option>
                  <option value="Raw">Raw Memory Address Poke</option>
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-zinc-300 font-medium">
                    Cheat Code <span className="text-rose-400">*</span>
                  </label>
                  <span className="text-[10px] text-zinc-400">
                    Supports multiline codes and spaces
                  </span>
                </div>
                <textarea
                  rows={4}
                  placeholder={`82003884 03E7\nXXXXXXXX YYYYYYYY`}
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full px-3 py-2 bg-[#0a0c10] border border-[#262e3d] rounded-xl text-indigo-200 font-mono text-xs focus:outline-none focus:border-indigo-500 placeholder-zinc-600"
                />
              </div>

              <div>
                <label className="block text-zinc-300 font-medium mb-1">
                  Notes / Instructions (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Master code must be enabled first, withdraw from PC slot 1"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-[#181d27] border border-[#262e3d] rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Validation Status Preview */}
              {code.trim() && (
                <div
                  className={`p-3 rounded-xl border text-[11px] flex items-start gap-2.5 ${
                    validation.isValid
                      ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-200'
                      : 'bg-rose-950/40 border-rose-800/60 text-rose-200'
                  }`}
                >
                  {validation.isValid ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-400 mt-0.5 shrink-0" />
                  )}
                  <div>
                    <span className="font-semibold">
                      {validation.isValid
                        ? `Valid ${validation.detectedFormat} syntax detected`
                        : 'Syntax Validation Error'}
                    </span>
                    {validation.errorMessage && (
                      <p className="mt-0.5 text-zinc-400">{validation.errorMessage}</p>
                    )}
                    {validation.isValid && (
                      <p className="mt-0.5 text-emerald-400/80 font-mono text-[10px]">
                        Normalized: {validation.normalizedCode.replace(/\n/g, ' | ')}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={handleCloseModal}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl font-medium text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCheat}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold text-xs shadow-lg transition-colors cursor-pointer"
              >
                {modalMode === 'edit' ? 'Update Cheat' : 'Save Cheat Code'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Preset Library Modal */}
      {showPresetsModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12151d] border border-[#242b38] rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col p-5 shadow-2xl text-white space-y-4">
            <div className="flex items-center justify-between border-b border-[#212734] pb-3 shrink-0">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold">Curated GBA Cheat Presets Library</h3>
              </div>
              <button
                onClick={() => setShowPresetsModal(false)}
                className="text-zinc-400 hover:text-white text-xs px-2.5 py-1 bg-zinc-800 rounded-lg cursor-pointer"
              >
                Close
              </button>
            </div>

            <p className="text-xs text-zinc-400 shrink-0">
              Tested Action Replay and CodeBreaker cheat codes for popular Game Boy Advance games. Click &quot;Import&quot; to add any code to your active list.
            </p>

            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              {CHEAT_PRESETS.map((group) => {
                const isMatchedGame = activeGame && group.gameIdMatch?.some((m) =>
                  activeGame.id.toLowerCase().includes(m) ||
                  activeGame.title.toLowerCase().includes(m) ||
                  (activeGame.code && activeGame.code.toLowerCase().includes(m))
                );

                return (
                  <div
                    key={group.gameTitle}
                    className={`p-4 rounded-xl border ${
                      isMatchedGame
                        ? 'bg-amber-950/20 border-amber-500/50 shadow-sm'
                        : 'bg-[#151923] border-[#222b3b]'
                    } space-y-3`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Gamepad2 className={`w-4 h-4 ${isMatchedGame ? 'text-amber-400' : 'text-zinc-400'}`} />
                        <span className="font-bold text-sm text-white">{group.gameTitle}</span>
                        {isMatchedGame && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40">
                            Current Game Match
                          </span>
                        )}
                      </div>
                      <button
                        onClick={() => handleImportAllGroupPresets(group.cheats)}
                        className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Import All ({group.cheats.length})</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {group.cheats.map((preset) => (
                        <div
                          key={preset.name}
                          className="p-2.5 rounded-lg bg-[#0e1118] border border-[#1e2535] text-xs flex flex-col justify-between gap-2"
                        >
                          <div>
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-semibold text-zinc-200">{preset.name}</span>
                              <span className="font-mono text-[9px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">
                                {preset.format}
                              </span>
                            </div>
                            <p className="text-[11px] text-zinc-400 mt-1">{preset.description}</p>
                            <pre className="mt-1 text-[10px] font-mono text-amber-300/90 bg-[#07090e] p-1.5 rounded overflow-x-auto">
                              {preset.code}
                            </pre>
                          </div>
                          <button
                            onClick={() => handleImportPresetItem(preset)}
                            className="self-end px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-[11px] font-medium transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Plus className="w-3 h-3 text-indigo-400" />
                            <span>Add to Cheats</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12151d] border border-[#242b38] rounded-2xl max-w-lg w-full p-5 shadow-2xl space-y-4 text-white">
            <div className="flex items-center justify-between border-b border-[#212734] pb-3">
              <div className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold">Import Cheats from JSON</h3>
              </div>
              <button
                onClick={() => setShowImportModal(false)}
                className="text-zinc-400 hover:text-white text-xs px-2.5 py-1 bg-zinc-800 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-zinc-400">
                Paste an exported JSON array of cheat objects, or upload a JSON backup file:
              </p>

              <div>
                <input
                  type="file"
                  accept=".json"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (evt) => {
                        const content = evt.target?.result as string;
                        if (content) setImportJsonText(content);
                      };
                      reader.readAsText(file);
                    }
                  }}
                  className="block w-full text-xs text-zinc-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-zinc-800 file:text-zinc-200 hover:file:bg-zinc-700 cursor-pointer"
                />
              </div>

              <textarea
                rows={6}
                placeholder={`[\n  {\n    "name": "Infinite Lives",\n    "code": "02002100 00000063",\n    "format": "ActionReplay"\n  }\n]`}
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                className="w-full px-3 py-2 bg-[#0a0c10] border border-[#262e3d] rounded-xl text-indigo-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={() => setShowImportModal(false)}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl font-medium text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleProcessImportJson}
                disabled={!importJsonText.trim()}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold text-xs shadow-lg disabled:opacity-40 transition-colors cursor-pointer"
              >
                Import Cheats
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
