import React, { useState } from 'react';
import { EmulatorSettings } from '../types';
import { WolfIcon } from './WolfIcon';
import {
  Settings as SettingsIcon,
  Monitor,
  Volume2,
  Cpu,
  Sliders,
  Bot,
  Info,
  RotateCcw,
  Check,
  Move,
  Smartphone,
  Gamepad,
  Tv,
  Sparkles,
} from 'lucide-react';
import { DEFAULT_SETTINGS } from '../utils/storage';

interface SettingsModalProps {
  settings: EmulatorSettings;
  onUpdateSettings: (settings: EmulatorSettings) => void;
  onOpenTouchEditor: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onOpenTouchEditor,
}) => {
  const [activeTab, setActiveTab] = useState<'video' | 'layout' | 'audio' | 'emulation' | 'ai' | 'about'>('video');

  const handleReset = () => {
    if (confirm('Reset all emulator settings to default configuration?')) {
      onUpdateSettings(DEFAULT_SETTINGS);
    }
  };

  const applyPreset = (presetName: string) => {
    if (presetName === 'default') {
      onUpdateSettings({
        ...settings,
        video: {
          ...settings.video,
          screenLayout: { scale: 1.0, x: 0, y: 0 },
        },
        controls: {
          ...settings.controls,
          touchLayout: { ...DEFAULT_SETTINGS.controls.touchLayout },
        },
      });
    } else if (presetName === 'thumb-reach') {
      onUpdateSettings({
        ...settings,
        video: {
          ...settings.video,
          screenLayout: { scale: 1.05, x: 0, y: -8 },
        },
        controls: {
          ...settings.controls,
          touchLayout: {
            ...settings.controls.touchLayout,
            dpad: { x: 14, y: 78, scale: 1.1 },
            actionButtons: { x: 84, y: 78, scale: 1.1 },
            shoulderButtons: { x: 4, y: 22, scale: 1.05 },
            systemButtons: { x: 50, y: 92, scale: 0.95 },
          },
        },
      });
    } else if (presetName === 'large-screen') {
      onUpdateSettings({
        ...settings,
        video: {
          ...settings.video,
          screenLayout: { scale: 1.25, x: 0, y: -16 },
        },
        controls: {
          ...settings.controls,
          touchLayout: {
            ...settings.controls.touchLayout,
            dpad: { x: 15, y: 82, scale: 1.0 },
            actionButtons: { x: 84, y: 82, scale: 1.0 },
            shoulderButtons: { x: 3, y: 35, scale: 0.95 },
            systemButtons: { x: 50, y: 94, scale: 0.9 },
          },
        },
      });
    } else if (presetName === 'compact') {
      onUpdateSettings({
        ...settings,
        video: {
          ...settings.video,
          screenLayout: { scale: 1.0, x: 0, y: 0 },
        },
        controls: {
          ...settings.controls,
          touchLayout: {
            ...settings.controls.touchLayout,
            dpad: { x: 12, y: 75, scale: 0.85 },
            actionButtons: { x: 86, y: 75, scale: 0.85 },
            shoulderButtons: { x: 3, y: 4, scale: 0.85 },
            systemButtons: { x: 50, y: 88, scale: 0.85 },
          },
        },
      });
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#1f2533] pb-5">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <SettingsIcon className="w-6 h-6 text-indigo-400" />
            <span>Emulator Preferences</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Display scaling, audio fidelity, emulation multipliers, and SHEILA AI intelligence options.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="flex items-center gap-1.5 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-medium transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Restore Default Settings</span>
        </button>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-[#202735] pb-2 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveTab('video')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-medium transition-colors ${
            activeTab === 'video'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Video & Display</span>
        </button>

        <button
          onClick={() => setActiveTab('layout')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-medium transition-colors ${
            activeTab === 'layout'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Sliders className="w-3.5 h-3.5 text-indigo-400" />
          <span>Screen & Controls Layout</span>
        </button>

        <button
          onClick={() => setActiveTab('audio')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-medium transition-colors ${
            activeTab === 'audio'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Volume2 className="w-3.5 h-3.5" />
          <span>Audio</span>
        </button>

        <button
          onClick={() => setActiveTab('emulation')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-medium transition-colors ${
            activeTab === 'emulation'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>Emulation</span>
        </button>

        <button
          onClick={() => setActiveTab('ai')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-medium transition-colors ${
            activeTab === 'ai'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Bot className="w-3.5 h-3.5" />
          <span>SHEILA AI</span>
        </button>

        <button
          onClick={() => setActiveTab('about')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-medium transition-colors ${
            activeTab === 'about'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
          }`}
        >
          <Info className="w-3.5 h-3.5" />
          <span>About & Licenses</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div className="bg-[#11151e] border border-[#212937] rounded-2xl p-5 text-xs text-zinc-300 space-y-6">
        {/* Video Tab */}
        {activeTab === 'video' && (
          <div className="space-y-5">
            {/* Aspect Ratio */}
            <div className="space-y-2">
              <label className="font-semibold text-white block">Aspect Ratio</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: '3:2', label: '3:2 Native (Recommended)', desc: 'Exact GBA 240x160 hardware ratio' },
                  { id: '16:9', label: '16:9 Widescreen', desc: 'Stretched modern widescreen' },
                  { id: 'fill', label: 'Stretch to Window', desc: 'Fills viewport completely' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        video: { ...settings.video, aspectRatio: item.id as any },
                      })
                    }
                    className={`p-3 rounded-xl border text-left transition-all ${
                      settings.video.aspectRatio === item.id
                        ? 'bg-indigo-950/60 border-indigo-500 text-white ring-1 ring-indigo-500'
                        : 'bg-[#171c26] border-[#252d3c] text-zinc-400 hover:text-white'
                    }`}
                  >
                    <span className="font-bold text-xs block mb-1">{item.label}</span>
                    <span className="text-[11px] text-zinc-400 block">{item.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Scaling Mode */}
            <div className="space-y-2">
              <label className="font-semibold text-white block">Image Scaling Algorithm</label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'pixelated', label: 'Pixel-Perfect (Nearest Neighbor)', desc: 'Sharp, razor-crisp retro pixels' },
                  { id: 'smooth', label: 'Bilinear Filter (Smooth)', desc: 'Softened anti-aliased texture edges' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        video: { ...settings.video, scaling: item.id as any },
                      })
                    }
                    className={`p-3 rounded-xl border text-left transition-all ${
                      settings.video.scaling === item.id
                        ? 'bg-indigo-950/60 border-indigo-500 text-white ring-1 ring-indigo-500'
                        : 'bg-[#171c26] border-[#252d3c] text-zinc-400 hover:text-white'
                    }`}
                  >
                    <span className="font-bold text-xs block mb-1">{item.label}</span>
                    <span className="text-[11px] text-zinc-400 block">{item.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Display Filters */}
            <div className="space-y-2">
              <label className="font-semibold text-white block">Post-Processing Screen Filter</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'none', label: 'Clean Original', desc: 'No shader or filter overlay' },
                  { id: 'scanlines', label: 'Retro Scanlines', desc: 'Subtle horizontal cathode-ray scanlines' },
                  { id: 'lcd', label: 'GBA LCD Grid', desc: 'Dot-matrix subpixel grid simulation' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        video: { ...settings.video, filter: item.id as any },
                      })
                    }
                    className={`p-3 rounded-xl border text-left transition-all ${
                      settings.video.filter === item.id
                        ? 'bg-indigo-950/60 border-indigo-500 text-white ring-1 ring-indigo-500'
                        : 'bg-[#171c26] border-[#252d3c] text-zinc-400 hover:text-white'
                    }`}
                  >
                    <span className="font-bold text-xs block mb-1">{item.label}</span>
                    <span className="text-[11px] text-zinc-400 block">{item.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Layout & Controls Customization Tab */}
        {activeTab === 'layout' && (
          <div className="space-y-6">
            {/* Visual Customizer Launch Banner */}
            <div className="bg-gradient-to-r from-indigo-950/70 via-[#161c28] to-purple-950/60 border border-indigo-700/50 p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shrink-0">
                  <Move className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-sm">Interactive Visual Drag & Drop Customizer</h3>
                  <p className="text-xs text-zinc-300 mt-0.5">
                    Drag elements directly on screen, pinch/scale, and position buttons right where your thumbs naturally sit.
                  </p>
                </div>
              </div>

              <button
                onClick={onOpenTouchEditor}
                className="w-full sm:w-auto px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/30 transition-all active:scale-95 flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <Move className="w-4 h-4" />
                <span>Launch Drag & Drop Editor</span>
              </button>
            </div>

            {/* Comfort Presets */}
            <div className="space-y-2">
              <label className="font-semibold text-white flex items-center gap-1.5 text-xs">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Ergonomic Layout Presets</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { id: 'thumb-reach', label: 'S24 Ultra / Thumb Comfort', desc: 'Lowered controls for big screens' },
                  { id: 'large-screen', label: 'Big Screen Focus', desc: '1.25x top screen, bottom controls' },
                  { id: 'compact', label: 'Compact Mini', desc: '0.85x sleek mini footprint' },
                  { id: 'default', label: 'Classic GBA', desc: 'Original balanced handheld layout' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => applyPreset(item.id)}
                    className="p-2.5 rounded-xl bg-[#171c26] border border-[#232a38] hover:border-indigo-500 hover:bg-indigo-950/30 text-left transition-all group"
                  >
                    <span className="font-bold text-xs text-white block mb-0.5 group-hover:text-indigo-300">
                      {item.label}
                    </span>
                    <span className="text-[10px] text-zinc-400 block leading-tight">{item.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Screen Size & Position */}
            <div className="bg-[#161c28] border border-[#232b3c] p-4 rounded-xl space-y-3">
              <div className="flex items-center justify-between border-b border-[#212838] pb-2">
                <div className="flex items-center gap-2">
                  <Tv className="w-4 h-4 text-indigo-400" />
                  <span className="font-bold text-white text-xs">Gameplay Screen Scaling & Position</span>
                </div>
                <span className="font-mono text-indigo-400 font-semibold text-xs">
                  {Math.round((settings.video.screenLayout?.scale || 1.0) * 100)}%
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                <div>
                  <div className="flex justify-between text-zinc-300 mb-1">
                    <span>Screen Scale</span>
                    <span className="font-mono text-indigo-400">
                      {((settings.video.screenLayout?.scale || 1.0) * 100).toFixed(0)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.6"
                    max="1.5"
                    step="0.05"
                    value={settings.video.screenLayout?.scale || 1.0}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        video: {
                          ...settings.video,
                          screenLayout: {
                            ...(settings.video.screenLayout || { scale: 1, x: 0, y: 0 }),
                            scale: parseFloat(e.target.value),
                          },
                        },
                      })
                    }
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-zinc-300 mb-1">
                    <span>Vertical Position (Y Offset)</span>
                    <span className="font-mono text-indigo-400">
                      {settings.video.screenLayout?.y || 0}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-30"
                    max="30"
                    step="1"
                    value={settings.video.screenLayout?.y || 0}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        video: {
                          ...settings.video,
                          screenLayout: {
                            ...(settings.video.screenLayout || { scale: 1, x: 0, y: 0 }),
                            y: parseInt(e.target.value),
                          },
                        },
                      })
                    }
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-zinc-300 mb-1">
                    <span>Horizontal Position (X Offset)</span>
                    <span className="font-mono text-indigo-400">
                      {settings.video.screenLayout?.x || 0}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-30"
                    max="30"
                    step="1"
                    value={settings.video.screenLayout?.x || 0}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        video: {
                          ...settings.video,
                          screenLayout: {
                            ...(settings.video.screenLayout || { scale: 1, x: 0, y: 0 }),
                            x: parseInt(e.target.value),
                          },
                        },
                      })
                    }
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Touch Controls Sizing & Placement Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* D-Pad */}
              <div className="bg-[#161c28] border border-[#232b3c] p-3.5 rounded-xl space-y-2.5">
                <div className="flex justify-between items-center text-white font-bold border-b border-[#212838] pb-1.5">
                  <span>D-Pad Directional Cross</span>
                  <span className="font-mono text-indigo-400 font-semibold">
                    {settings.controls.touchLayout.dpad.scale.toFixed(1)}x
                  </span>
                </div>
                <div>
                  <label className="text-zinc-400 block mb-1">Size Scale (0.6x - 1.8x)</label>
                  <input
                    type="range"
                    min="0.6"
                    max="1.8"
                    step="0.05"
                    value={settings.controls.touchLayout.dpad.scale}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        controls: {
                          ...settings.controls,
                          touchLayout: {
                            ...settings.controls.touchLayout,
                            dpad: {
                              ...settings.controls.touchLayout.dpad,
                              scale: parseFloat(e.target.value),
                            },
                          },
                        },
                      })
                    }
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-zinc-400 block">Horiz (X %)</label>
                    <input
                      type="range"
                      min="5"
                      max="45"
                      value={settings.controls.touchLayout.dpad.x}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          controls: {
                            ...settings.controls,
                            touchLayout: {
                              ...settings.controls.touchLayout,
                              dpad: {
                                ...settings.controls.touchLayout.dpad,
                                x: parseInt(e.target.value),
                              },
                            },
                          },
                        })
                      }
                      className="w-full accent-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 block">Vert (Y %)</label>
                    <input
                      type="range"
                      min="30"
                      max="95"
                      value={settings.controls.touchLayout.dpad.y}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          controls: {
                            ...settings.controls,
                            touchLayout: {
                              ...settings.controls.touchLayout,
                              dpad: {
                                ...settings.controls.touchLayout.dpad,
                                y: parseInt(e.target.value),
                              },
                            },
                          },
                        })
                      }
                      className="w-full accent-indigo-500"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons A & B */}
              <div className="bg-[#161c28] border border-[#232b3c] p-3.5 rounded-xl space-y-2.5">
                <div className="flex justify-between items-center text-white font-bold border-b border-[#212838] pb-1.5">
                  <span>Action Buttons (A & B)</span>
                  <span className="font-mono text-indigo-400 font-semibold">
                    {settings.controls.touchLayout.actionButtons.scale.toFixed(1)}x
                  </span>
                </div>
                <div>
                  <label className="text-zinc-400 block mb-1">Size Scale (0.6x - 1.8x)</label>
                  <input
                    type="range"
                    min="0.6"
                    max="1.8"
                    step="0.05"
                    value={settings.controls.touchLayout.actionButtons.scale}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        controls: {
                          ...settings.controls,
                          touchLayout: {
                            ...settings.controls.touchLayout,
                            actionButtons: {
                              ...settings.controls.touchLayout.actionButtons,
                              scale: parseFloat(e.target.value),
                            },
                          },
                        },
                      })
                    }
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-zinc-400 block">Horiz (X %)</label>
                    <input
                      type="range"
                      min="55"
                      max="95"
                      value={settings.controls.touchLayout.actionButtons.x}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          controls: {
                            ...settings.controls,
                            touchLayout: {
                              ...settings.controls.touchLayout,
                              actionButtons: {
                                ...settings.controls.touchLayout.actionButtons,
                                x: parseInt(e.target.value),
                              },
                            },
                          },
                        })
                      }
                      className="w-full accent-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 block">Vert (Y %)</label>
                    <input
                      type="range"
                      min="30"
                      max="95"
                      value={settings.controls.touchLayout.actionButtons.y}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          controls: {
                            ...settings.controls,
                            touchLayout: {
                              ...settings.controls.touchLayout,
                              actionButtons: {
                                ...settings.controls.touchLayout.actionButtons,
                                y: parseInt(e.target.value),
                              },
                            },
                          },
                        })
                      }
                      className="w-full accent-indigo-500"
                    />
                  </div>
                </div>
              </div>

              {/* Shoulder Triggers L & R */}
              <div className="bg-[#161c28] border border-[#232b3c] p-3.5 rounded-xl space-y-2.5">
                <div className="flex justify-between items-center text-white font-bold border-b border-[#212838] pb-1.5">
                  <span>Shoulder Triggers (L & R)</span>
                  <span className="font-mono text-indigo-400 font-semibold">
                    {settings.controls.touchLayout.shoulderButtons.scale.toFixed(1)}x
                  </span>
                </div>
                <div>
                  <label className="text-zinc-400 block mb-1">Trigger Size</label>
                  <input
                    type="range"
                    min="0.6"
                    max="1.8"
                    step="0.05"
                    value={settings.controls.touchLayout.shoulderButtons.scale}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        controls: {
                          ...settings.controls,
                          touchLayout: {
                            ...settings.controls.touchLayout,
                            shoulderButtons: {
                              ...settings.controls.touchLayout.shoulderButtons,
                              scale: parseFloat(e.target.value),
                            },
                          },
                        },
                      })
                    }
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-[10px] text-zinc-400 mb-1">
                    <span>Vertical Height (Lower for thumb reach on tall phones)</span>
                    <span className="font-mono text-indigo-400">
                      {settings.controls.touchLayout.shoulderButtons.y}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="45"
                    value={settings.controls.touchLayout.shoulderButtons.y}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        controls: {
                          ...settings.controls,
                          touchLayout: {
                            ...settings.controls.touchLayout,
                            shoulderButtons: {
                              ...settings.controls.touchLayout.shoulderButtons,
                              y: parseInt(e.target.value),
                            },
                          },
                        },
                      })
                    }
                    className="w-full accent-indigo-500"
                  />
                </div>
              </div>

              {/* Global Button Opacity & Haptics */}
              <div className="bg-[#161c28] border border-[#232b3c] p-3.5 rounded-xl space-y-3">
                <div className="text-white font-bold border-b border-[#212838] pb-1.5">
                  Button Appearance & Feedback
                </div>
                <div>
                  <div className="flex justify-between text-zinc-300 mb-1">
                    <span>Overlay Opacity</span>
                    <span className="font-mono text-indigo-400">
                      {Math.round(settings.controls.touchLayout.opacity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="1.0"
                    step="0.05"
                    value={settings.controls.touchLayout.opacity}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        controls: {
                          ...settings.controls,
                          touchLayout: {
                            ...settings.controls.touchLayout,
                            opacity: parseFloat(e.target.value),
                          },
                        },
                      })
                    }
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-zinc-900/80 border border-zinc-700 cursor-pointer">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-indigo-400" />
                    <span className="font-medium text-white">Haptic Vibration on Tap</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.controls.touchLayout.haptics}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        controls: {
                          ...settings.controls,
                          touchLayout: {
                            ...settings.controls.touchLayout,
                            haptics: e.target.checked,
                          },
                        },
                      })
                    }
                    className="rounded accent-indigo-600 w-4 h-4"
                  />
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Audio Tab */}
        {activeTab === 'audio' && (
          <div className="space-y-5 max-w-md">
            <div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-white">Master Volume</span>
                <span className="font-mono text-indigo-400 font-bold">{settings.audio.volume}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.audio.volume}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    audio: { ...settings.audio, volume: parseInt(e.target.value) },
                  })
                }
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>

            <label className="flex items-center justify-between p-3 rounded-xl bg-[#181d27] border border-[#242b38] cursor-pointer">
              <div>
                <span className="font-semibold text-white block">Mute Audio</span>
                <span className="text-[11px] text-zinc-400">Silences hardware sound channels</span>
              </div>
              <input
                type="checkbox"
                checked={settings.audio.muted}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    audio: { ...settings.audio, muted: e.target.checked },
                  })
                }
                className="w-4 h-4 rounded accent-indigo-600"
              />
            </label>
          </div>
        )}

        {/* Emulation Tab */}
        {activeTab === 'emulation' && (
          <div className="space-y-5">
            <div>
              <label className="font-semibold text-white block mb-2">
                Fast-Forward Speed Multiplier
              </label>
              <div className="grid grid-cols-4 gap-3">
                {([2, 3, 4, 8] as const).map((speed) => (
                  <button
                    key={speed}
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        emulation: { ...settings.emulation, fastForwardSpeed: speed },
                      })
                    }
                    className={`py-2.5 rounded-xl border font-mono font-bold text-xs transition-all ${
                      settings.emulation.fastForwardSpeed === speed
                        ? 'bg-amber-600 border-amber-500 text-white shadow-md'
                        : 'bg-[#181d27] border-[#252d3c] text-zinc-400 hover:text-white'
                    }`}
                  >
                    {speed}x Normal
                  </button>
                ))}
              </div>
            </div>

            {/* Auto-Save Configuration */}
            <div className="bg-[#161c28] border border-emerald-500/30 rounded-xl p-4 space-y-4">
              <div className="flex items-center justify-between border-b border-[#232b3c] pb-3">
                <div>
                  <span className="font-bold text-white text-sm flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    Periodic Auto-Save (Background Snapshots)
                  </span>
                  <span className="text-[11px] text-zinc-400 block mt-0.5">
                    Freezes state in the background into Slot 0 to guarantee zero progress loss.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.general.autoSaveEnabled ?? true}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      general: { ...settings.general, autoSaveEnabled: e.target.checked },
                    })
                  }
                  className="w-4 h-4 rounded accent-emerald-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="text-zinc-300 font-semibold block mb-2">
                  Auto-Save Frequency Interval
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {[1, 3, 5, 10, 15].map((mins) => (
                    <button
                      key={mins}
                      onClick={() =>
                        onUpdateSettings({
                          ...settings,
                          general: { ...settings.general, autoSaveIntervalMinutes: mins },
                        })
                      }
                      className={`py-2 rounded-lg border font-mono text-xs transition-colors cursor-pointer ${
                        (settings.general.autoSaveIntervalMinutes ?? 5) === mins
                          ? 'bg-emerald-600 border-emerald-500 text-white font-bold shadow'
                          : 'bg-[#10141e] border-[#222938] text-zinc-400 hover:text-white'
                      }`}
                    >
                      {mins}m {mins === 5 ? '(Default)' : ''}
                    </button>
                  ))}
                </div>
              </div>

              <label className="flex items-center justify-between pt-2 border-t border-[#232b3c] cursor-pointer">
                <div>
                  <span className="font-semibold text-white block">Auto-Save on Game Exit / Unload</span>
                  <span className="text-[11px] text-zinc-400">
                    Snapshots emulator state when switching games, closing tabs, or navigating away
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.general.autoSaveOnExit ?? true}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      general: { ...settings.general, autoSaveOnExit: e.target.checked },
                    })
                  }
                  className="w-4 h-4 rounded accent-emerald-500 cursor-pointer"
                />
              </label>
            </div>

            <label className="flex items-center justify-between p-3 rounded-xl bg-[#181d27] border border-[#242b38] cursor-pointer">
              <div>
                <span className="font-semibold text-white block">Auto-Save Battery SRAM</span>
                <span className="text-[11px] text-zinc-400">
                  Automatically syncs in-game cartridge saves to local storage
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.general.autoSaveBattery}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    general: { ...settings.general, autoSaveBattery: e.target.checked },
                  })
                }
                className="w-4 h-4 rounded accent-indigo-600"
              />
            </label>
          </div>
        )}

        {/* AI Tab */}
        {activeTab === 'ai' && (
          <div className="space-y-5">
            <div className="p-4 rounded-xl bg-[#181d27] border border-[#242b38] space-y-2">
              <div className="flex items-center gap-2">
                <Bot className="w-4 h-4 text-indigo-400" />
                <span className="font-semibold text-white">SHEILA AI Intelligence</span>
              </div>
              <p className="text-zinc-400 text-xs leading-relaxed">
                Powered by Google Gemini 3.8 Flash. Assists with game guides, cheat code lookups, GBA memory architectures, and Android APK deployment.
              </p>
            </div>

            <label className="flex items-center justify-between p-3 rounded-xl bg-[#181d27] border border-[#242b38] cursor-pointer">
              <div>
                <span className="font-semibold text-white block">Enable Google Search Grounding</span>
                <span className="text-[11px] text-zinc-400">
                  Allows SHEILA AI to look up live cheat codes and game secrets from the web
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.ai.enableOnlineSearch}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    ai: { ...settings.ai, enableOnlineSearch: e.target.checked },
                  })
                }
                className="w-4 h-4 rounded accent-indigo-600"
              />
            </label>
          </div>
        )}

        {/* About Tab */}
        {activeTab === 'about' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-[#1f2635]">
              <WolfIcon size={44} />
              <div>
                <h3 className="font-bold text-white text-sm">SHEILA GBA EMU</h3>
                <span className="text-[11px] text-indigo-300 font-mono">v1.0.0 Release</span>
              </div>
            </div>

            <div className="space-y-2 text-[11px] text-zinc-400 leading-relaxed">
              <p>
                <strong className="text-zinc-200">Architecture:</strong> High-performance Game Boy Advance core utilizing ARM7TDMI 32-bit RISC processor emulation, hardware cycle timers, direct scanline software rasterization, and direct sound DMA audio synthesizers.
              </p>
              <p>
                <strong className="text-zinc-200">Homebrew Library:</strong> Includes legally licensed, open-source Game Boy Advance homebrew games: Frogtris, Gapman, Impact, and Tetravex.
              </p>
              <p>
                <strong className="text-zinc-200">Legal Disclaimer:</strong> Game Boy Advance is a registered trademark of Nintendo Co., Ltd. SHEILA GBA EMU is not affiliated with or endorsed by Nintendo. All game backups should be dumped from physical cartridges legally owned by the user.
              </p>
              <p>
                <strong className="text-zinc-200">Licenses:</strong> BSD-2-Clause & MIT Open Source Software.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
