import React, { useCallback, useState } from 'react';
import { TouchLayoutConfig } from '../types';
import { emulatorInstance } from '../emulator/GBAEmulator';

interface TouchControlsProps {
  layout: TouchLayoutConfig;
  visible: boolean;
}

export const TouchControls: React.FC<TouchControlsProps> = ({ layout, visible }) => {
  const [activeKeys, setActiveKeys] = useState<Record<string, boolean>>({});

  const triggerHaptic = useCallback(() => {
    if (!layout.haptics) return;
    try {
      if ((window as any).SheilaNative && typeof (window as any).SheilaNative.vibrate === 'function') {
        (window as any).SheilaNative.vibrate(15);
      } else if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(15);
      }
    } catch {
      // ignore
    }
  }, [layout.haptics]);

  const handlePress = useCallback(
    (key: string, e: React.TouchEvent | React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      triggerHaptic();
      setActiveKeys((prev) => ({ ...prev, [key]: true }));
      emulatorInstance.pressKey(key);
    },
    [triggerHaptic]
  );

  const handleRelease = useCallback(
    (key: string, e: React.TouchEvent | React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setActiveKeys((prev) => ({ ...prev, [key]: false }));
      emulatorInstance.releaseKey(key);
    },
    []
  );

  const handleDiagonalPress = useCallback(
    (key1: string, key2: string, e: React.TouchEvent | React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      triggerHaptic();
      setActiveKeys((prev) => ({ ...prev, [key1]: true, [key2]: true, [`${key1}_${key2}`]: true }));
      emulatorInstance.pressKey(key1);
      emulatorInstance.pressKey(key2);
    },
    [triggerHaptic]
  );

  const handleDiagonalRelease = useCallback(
    (key1: string, key2: string, e: React.TouchEvent | React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setActiveKeys((prev) => ({ ...prev, [key1]: false, [key2]: false, [`${key1}_${key2}`]: false }));
      emulatorInstance.releaseKey(key1);
      emulatorInstance.releaseKey(key2);
    },
    []
  );

  if (!visible) return null;

  const opacity = layout.opacity;

  return (
    <div
      className="absolute inset-0 pointer-events-none select-none z-20 overflow-hidden"
      style={{ opacity }}
    >
      {/* Shoulder Triggers L & R (Adjustable positioning & scale) */}
      <div
        className="absolute pointer-events-auto"
        style={{
          top: `${layout.shoulderButtons.y}%`,
          left: `${layout.shoulderButtons.x < 50 ? layout.shoulderButtons.x : 3}%`,
          transform: `scale(${layout.shoulderButtons.scale})`,
          transformOrigin: 'top left',
        }}
      >
        <button
          onTouchStart={(e) => handlePress('L', e)}
          onTouchEnd={(e) => handleRelease('L', e)}
          onMouseDown={(e) => handlePress('L', e)}
          onMouseUp={(e) => handleRelease('L', e)}
          className={`w-24 h-12 rounded-2xl font-bold text-sm tracking-widest flex items-center justify-center transition-all duration-75 shadow-lg border touch-none ${
            activeKeys['L']
              ? 'bg-indigo-600 text-white border-indigo-400 shadow-indigo-500/50 scale-95'
              : 'bg-gradient-to-b from-zinc-800/90 to-zinc-900/95 text-zinc-300 border-zinc-700/80 hover:border-zinc-500'
          }`}
          aria-label="L Trigger"
        >
          <span className="drop-shadow">TRIGGER L</span>
        </button>
      </div>

      <div
        className="absolute pointer-events-auto"
        style={{
          top: `${layout.shoulderButtons.y}%`,
          right: `${layout.shoulderButtons.x < 50 ? layout.shoulderButtons.x : 3}%`,
          transform: `scale(${layout.shoulderButtons.scale})`,
          transformOrigin: 'top right',
        }}
      >
        <button
          onTouchStart={(e) => handlePress('R', e)}
          onTouchEnd={(e) => handleRelease('R', e)}
          onMouseDown={(e) => handlePress('R', e)}
          onMouseUp={(e) => handleRelease('R', e)}
          className={`w-24 h-12 rounded-2xl font-bold text-sm tracking-widest flex items-center justify-center transition-all duration-75 shadow-lg border touch-none ${
            activeKeys['R']
              ? 'bg-indigo-600 text-white border-indigo-400 shadow-indigo-500/50 scale-95'
              : 'bg-gradient-to-b from-zinc-800/90 to-zinc-900/95 text-zinc-300 border-zinc-700/80 hover:border-zinc-500'
          }`}
          aria-label="R Trigger"
        >
          <span className="drop-shadow">TRIGGER R</span>
        </button>
      </div>

      {/* D-Pad (Left hand zone with full 8-way diagonal sensitivity) */}
      <div
        className="absolute pointer-events-auto"
        style={{
          left: `${layout.dpad.x}%`,
          top: `${layout.dpad.y}%`,
          transform: `translate(-50%, -50%) scale(${layout.dpad.scale})`,
          transformOrigin: 'center center',
        }}
      >
        <div className="relative w-44 h-44 drop-shadow-2xl">
          {/* Subtle Outer Glow & Base Halo */}
          <div className="absolute inset-0 rounded-full bg-zinc-950/40 blur-sm pointer-events-none" />

          {/* D-Pad Cross Background Bodies */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-14 h-44 bg-gradient-to-b from-zinc-900 via-zinc-800 to-zinc-900 border-2 border-zinc-700/80 rounded-2xl shadow-inner" />
          </div>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-44 h-14 bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border-2 border-zinc-700/80 rounded-2xl shadow-inner" />
          </div>

          {/* Central Thumb Pivot indentation */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-10 h-10 bg-zinc-950/90 rounded-full border border-zinc-700/70 shadow-inner flex items-center justify-center">
              <div className="w-4 h-4 rounded-full bg-zinc-800/80" />
            </div>
          </div>

          {/* UP Button */}
          <button
            onTouchStart={(e) => handlePress('UP', e)}
            onTouchEnd={(e) => handleRelease('UP', e)}
            onMouseDown={(e) => handlePress('UP', e)}
            onMouseUp={(e) => handleRelease('UP', e)}
            className={`absolute top-0 left-14 w-16 h-14 flex items-center justify-center rounded-t-2xl touch-none transition-colors ${
              activeKeys['UP'] ? 'bg-indigo-600/70' : 'active:bg-indigo-600/50'
            }`}
            aria-label="D-Pad Up"
          >
            <span className={`text-xl font-bold transition-transform ${activeKeys['UP'] ? 'text-white scale-110' : 'text-zinc-300'}`}>▲</span>
          </button>

          {/* DOWN Button */}
          <button
            onTouchStart={(e) => handlePress('DOWN', e)}
            onTouchEnd={(e) => handleRelease('DOWN', e)}
            onMouseDown={(e) => handlePress('DOWN', e)}
            onMouseUp={(e) => handleRelease('DOWN', e)}
            className={`absolute bottom-0 left-14 w-16 h-14 flex items-center justify-center rounded-b-2xl touch-none transition-colors ${
              activeKeys['DOWN'] ? 'bg-indigo-600/70' : 'active:bg-indigo-600/50'
            }`}
            aria-label="D-Pad Down"
          >
            <span className={`text-xl font-bold transition-transform ${activeKeys['DOWN'] ? 'text-white scale-110' : 'text-zinc-300'}`}>▼</span>
          </button>

          {/* LEFT Button */}
          <button
            onTouchStart={(e) => handlePress('LEFT', e)}
            onTouchEnd={(e) => handleRelease('LEFT', e)}
            onMouseDown={(e) => handlePress('LEFT', e)}
            onMouseUp={(e) => handleRelease('LEFT', e)}
            className={`absolute top-14 left-0 w-14 h-16 flex items-center justify-center rounded-l-2xl touch-none transition-colors ${
              activeKeys['LEFT'] ? 'bg-indigo-600/70' : 'active:bg-indigo-600/50'
            }`}
            aria-label="D-Pad Left"
          >
            <span className={`text-xl font-bold transition-transform ${activeKeys['LEFT'] ? 'text-white scale-110' : 'text-zinc-300'}`}>◀</span>
          </button>

          {/* RIGHT Button */}
          <button
            onTouchStart={(e) => handlePress('RIGHT', e)}
            onTouchEnd={(e) => handleRelease('RIGHT', e)}
            onMouseDown={(e) => handlePress('RIGHT', e)}
            onMouseUp={(e) => handleRelease('RIGHT', e)}
            className={`absolute top-14 right-0 w-14 h-16 flex items-center justify-center rounded-r-2xl touch-none transition-colors ${
              activeKeys['RIGHT'] ? 'bg-indigo-600/70' : 'active:bg-indigo-600/50'
            }`}
            aria-label="D-Pad Right"
          >
            <span className={`text-xl font-bold transition-transform ${activeKeys['RIGHT'] ? 'text-white scale-110' : 'text-zinc-300'}`}>▶</span>
          </button>

          {/* Diagonal Corner Hitboxes (Up-Left, Up-Right, Down-Left, Down-Right) */}
          <button
            onTouchStart={(e) => handleDiagonalPress('UP', 'LEFT', e)}
            onTouchEnd={(e) => handleDiagonalRelease('UP', 'LEFT', e)}
            onMouseDown={(e) => handleDiagonalPress('UP', 'LEFT', e)}
            onMouseUp={(e) => handleDiagonalRelease('UP', 'LEFT', e)}
            className="absolute top-0 left-0 w-14 h-14 touch-none opacity-0"
            aria-label="D-Pad Up-Left"
          />
          <button
            onTouchStart={(e) => handleDiagonalPress('UP', 'RIGHT', e)}
            onTouchEnd={(e) => handleDiagonalRelease('UP', 'RIGHT', e)}
            onMouseDown={(e) => handleDiagonalPress('UP', 'RIGHT', e)}
            onMouseUp={(e) => handleDiagonalRelease('UP', 'RIGHT', e)}
            className="absolute top-0 right-0 w-14 h-14 touch-none opacity-0"
            aria-label="D-Pad Up-Right"
          />
          <button
            onTouchStart={(e) => handleDiagonalPress('DOWN', 'LEFT', e)}
            onTouchEnd={(e) => handleDiagonalRelease('DOWN', 'LEFT', e)}
            onMouseDown={(e) => handleDiagonalPress('DOWN', 'LEFT', e)}
            onMouseUp={(e) => handleDiagonalRelease('DOWN', 'LEFT', e)}
            className="absolute bottom-0 left-0 w-14 h-14 touch-none opacity-0"
            aria-label="D-Pad Down-Left"
          />
          <button
            onTouchStart={(e) => handleDiagonalPress('DOWN', 'RIGHT', e)}
            onTouchEnd={(e) => handleDiagonalRelease('DOWN', 'RIGHT', e)}
            onMouseDown={(e) => handleDiagonalPress('DOWN', 'RIGHT', e)}
            onMouseUp={(e) => handleDiagonalRelease('DOWN', 'RIGHT', e)}
            className="absolute bottom-0 right-0 w-14 h-14 touch-none opacity-0"
            aria-label="D-Pad Down-Right"
          />
        </div>
      </div>

      {/* Action Buttons A & B (Right Hand Zone with Ergonomic Tilt & Turbo) */}
      <div
        className="absolute pointer-events-auto"
        style={{
          left: `${layout.actionButtons.x}%`,
          top: `${layout.actionButtons.y}%`,
          transform: `translate(-50%, -50%) scale(${layout.actionButtons.scale})`,
          transformOrigin: 'center center',
        }}
      >
        <div className="relative w-44 h-36">
          {/* B Button (Lower Left - Crimson / Rose) */}
          <div className="absolute bottom-0 left-0 flex flex-col items-center gap-1">
            <button
              onTouchStart={(e) => handlePress('B', e)}
              onTouchEnd={(e) => handleRelease('B', e)}
              onMouseDown={(e) => handlePress('B', e)}
              onMouseUp={(e) => handleRelease('B', e)}
              className={`w-16 h-16 rounded-full flex items-center justify-center font-black text-2xl transition-all duration-75 shadow-xl border-2 touch-none ${
                activeKeys['B']
                  ? 'bg-rose-600 text-white border-rose-400 shadow-rose-500/60 scale-95'
                  : 'bg-gradient-to-br from-zinc-800 to-zinc-950 text-rose-400 border-rose-600/70 hover:border-rose-400'
              }`}
              aria-label="B Button"
            >
              <span className="drop-shadow-md">B</span>
            </button>
            <span className="text-[10px] font-mono font-bold text-zinc-400 tracking-wider">CANCEL</span>
          </div>

          {/* A Button (Upper Right - Emerald / Green) */}
          <div className="absolute top-0 right-0 flex flex-col items-center gap-1">
            <button
              onTouchStart={(e) => handlePress('A', e)}
              onTouchEnd={(e) => handleRelease('A', e)}
              onMouseDown={(e) => handlePress('A', e)}
              onMouseUp={(e) => handleRelease('A', e)}
              className={`w-16 h-16 rounded-full flex items-center justify-center font-black text-2xl transition-all duration-75 shadow-xl border-2 touch-none ${
                activeKeys['A']
                  ? 'bg-emerald-600 text-white border-emerald-400 shadow-emerald-500/60 scale-95'
                  : 'bg-gradient-to-br from-zinc-800 to-zinc-950 text-emerald-400 border-emerald-600/70 hover:border-emerald-400'
              }`}
              aria-label="A Button"
            >
              <span className="drop-shadow-md">A</span>
            </button>
            <span className="text-[10px] font-mono font-bold text-zinc-400 tracking-wider">ACTION</span>
          </div>
        </div>
      </div>

      {/* System Buttons (SELECT & START Centered Pill) */}
      <div
        className="absolute pointer-events-auto"
        style={{
          left: `${layout.systemButtons.x}%`,
          top: `${layout.systemButtons.y}%`,
          transform: `translate(-50%, -50%) scale(${layout.systemButtons.scale})`,
          transformOrigin: 'center center',
        }}
      >
        <div className="flex items-center gap-6 bg-zinc-900/90 border border-zinc-700/80 px-5 py-2 rounded-full shadow-2xl backdrop-blur-md">
          {/* SELECT Button */}
          <button
            onTouchStart={(e) => handlePress('SELECT', e)}
            onTouchEnd={(e) => handleRelease('SELECT', e)}
            onMouseDown={(e) => handlePress('SELECT', e)}
            onMouseUp={(e) => handleRelease('SELECT', e)}
            className={`px-4 py-1.5 rounded-full text-[11px] font-bold tracking-widest uppercase transition-all duration-75 border touch-none ${
              activeKeys['SELECT']
                ? 'bg-indigo-600 text-white border-indigo-400 scale-95'
                : 'bg-zinc-800 text-zinc-300 border-zinc-700 hover:text-white'
            }`}
            aria-label="Select Button"
          >
            Select
          </button>

          {/* START Button */}
          <button
            onTouchStart={(e) => handlePress('START', e)}
            onTouchEnd={(e) => handleRelease('START', e)}
            onMouseDown={(e) => handlePress('START', e)}
            onMouseUp={(e) => handleRelease('START', e)}
            className={`px-4 py-1.5 rounded-full text-[11px] font-bold tracking-widest uppercase transition-all duration-75 border touch-none ${
              activeKeys['START']
                ? 'bg-indigo-600 text-white border-indigo-400 scale-95'
                : 'bg-zinc-800 text-zinc-300 border-zinc-700 hover:text-white'
            }`}
            aria-label="Start Button"
          >
            Start
          </button>
        </div>
      </div>
    </div>
  );
};
