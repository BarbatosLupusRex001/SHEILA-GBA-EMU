import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  Download,
  ExternalLink,
  Copy,
  Check,
  Smartphone,
  ShieldCheck,
  X,
  QrCode,
  Sparkles,
  AlertCircle,
} from 'lucide-react';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({ isOpen, onClose }) => {
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [isDownloadingSource, setIsDownloadingSource] = useState(false);

  // Derive absolute URLs
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-4cpiez5zlow56vcfajpvm7-904446916423.europe-west2.run.app';
  const directApkUrl = `${origin}/api/download-apk`;
  const staticApkUrl = `${origin}/sheila-gba-emu.apk`;
  const directSourceZipUrl = `${origin}/api/download-app-zip`;
  const directAndroidZipUrl = `${origin}/api/export-android-project`;

  useEffect(() => {
    if (isOpen) {
      QRCode.toDataURL(directApkUrl, {
        width: 240,
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      })
        .then((url) => setQrCodeDataUrl(url))
        .catch((err) => console.error('Failed to generate QR Code:', err));
    }
  }, [isOpen, directApkUrl]);

  if (!isOpen) return null;

  const handleBlobDownload = async () => {
    setIsDownloading(true);
    setDownloadSuccess(false);

    try {
      // Fetch binary blob directly to circumvent iframe navigation sandbox restrictions
      const response = await fetch(directApkUrl, { mode: 'cors' });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const tempLink = document.createElement('a');
      tempLink.href = blobUrl;
      tempLink.download = 'SHEILA-GBA-EMU.apk';
      tempLink.style.display = 'none';
      document.body.appendChild(tempLink);
      tempLink.click();
      document.body.removeChild(tempLink);
      window.URL.revokeObjectURL(blobUrl);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.warn('Blob download encountered an issue, falling back to direct window open:', err);
      window.open(directApkUrl, '_blank');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleSourceZipDownload = async () => {
    setIsDownloadingSource(true);
    try {
      const response = await fetch(directSourceZipUrl, { mode: 'cors' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const tempLink = document.createElement('a');
      tempLink.href = blobUrl;
      tempLink.download = 'SHEILA-GBA-EMU-source.zip';
      tempLink.style.display = 'none';
      document.body.appendChild(tempLink);
      tempLink.click();
      document.body.removeChild(tempLink);
      window.URL.revokeObjectURL(blobUrl);
    } catch (err) {
      window.open(directSourceZipUrl, '_blank');
    } finally {
      setIsDownloadingSource(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(directApkUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#10141d] border border-[#232c3d] rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl text-white space-y-5 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-emerald-950/80 border border-emerald-700/60 flex items-center justify-center text-emerald-400 shadow-inner">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span>Download SHEILA GBA APK</span>
              <span className="text-[10px] font-mono font-semibold bg-emerald-900/60 text-emerald-300 border border-emerald-700/60 px-2 py-0.5 rounded-full">
                v1.0.0
              </span>
            </h2>
            <p className="text-xs text-zinc-400">
              Native Android Package • Target SDK 34 (Android 14+) • Samsung Knox Ready
            </p>
          </div>
        </div>

        {/* Verification Badges */}
        <div className="grid grid-cols-3 gap-2 bg-[#171d29] border border-[#232d3f] p-2.5 rounded-xl text-[11px] text-zinc-300">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="truncate">Signed (v1-v3)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="truncate">S24 Ultra Ready</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="truncate">17 KB Native Core</span>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="space-y-2.5">
          <button
            onClick={handleBlobDownload}
            disabled={isDownloading}
            className={`w-full py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
              downloadSuccess
                ? 'bg-emerald-600 text-white shadow-emerald-600/30'
                : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-600/20 active:scale-[0.99]'
            }`}
          >
            {isDownloading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Preparing Download...</span>
              </>
            ) : downloadSuccess ? (
              <>
                <Check className="w-5 h-5" />
                <span>Download Started! Check Notifications</span>
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                <span>Download APK Directly Now</span>
              </>
            )}
          </button>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <a
              href={directApkUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 transition-colors font-medium text-center"
            >
              <ExternalLink className="w-3.5 h-3.5 text-indigo-400" />
              <span>Open Link in New Tab</span>
            </a>

            <button
              onClick={handleCopyLink}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 transition-colors font-medium text-center"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-300">Link Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Copy APK Link</span>
                </>
              )}
            </button>
          </div>

          {/* Alternative Source Code & Android Studio Package Downloads */}
          <div className="pt-2 border-t border-[#1e2533] space-y-2">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">
              Developer & Source Packages:
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={handleSourceZipDownload}
                disabled={isDownloadingSource}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 border border-indigo-700/60 transition-colors font-medium text-center"
                title="Download full project source code as a ZIP file"
              >
                <Download className="w-3.5 h-3.5 text-indigo-400" />
                <span>Full App Source (.ZIP)</span>
              </button>

              <a
                href={directAndroidZipUrl}
                download="SHEILA-GBA-EMU-android.zip"
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition-colors font-medium text-center"
                title="Download Android Studio native gradle project"
              >
                <Download className="w-3.5 h-3.5 text-zinc-400" />
                <span>Android Studio (.ZIP)</span>
              </a>
            </div>
          </div>
        </div>

        {/* QR Code Section for Instant Phone Scan */}
        <div className="bg-[#151a24] border border-[#222a3a] p-4 rounded-xl flex flex-col sm:flex-row items-center gap-4">
          <div className="bg-white p-2 rounded-lg shrink-0 shadow-md">
            {qrCodeDataUrl ? (
              <img
                src={qrCodeDataUrl}
                alt="Scan to download APK directly to phone"
                className="w-28 h-28"
              />
            ) : (
              <div className="w-28 h-28 flex items-center justify-center text-zinc-400">
                <QrCode className="w-8 h-8 animate-pulse" />
              </div>
            )}
          </div>
          <div className="space-y-1.5 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs font-semibold text-white">
              <QrCode className="w-3.5 h-3.5 text-indigo-400" />
              <span>Scan to Download on Phone</span>
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Point your Samsung Galaxy S24 Ultra camera at this QR code to download and install{' '}
              <strong className="text-zinc-200">SHEILA-GBA-EMU.apk</strong> immediately without typing any URL.
            </p>
          </div>
        </div>

        {/* Installation Instructions */}
        <div className="space-y-2 bg-[#121620] border border-[#1e2533] p-3.5 rounded-xl text-xs text-zinc-300">
          <div className="font-semibold text-white flex items-center gap-1.5 text-[11px]">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>Installation Guide (Samsung Galaxy & Android 14+):</span>
          </div>
          <ol className="list-decimal list-inside space-y-1 text-[11px] text-zinc-400 pl-1">
            <li>Tap the download button above or scan the QR code with your camera.</li>
            <li>When downloaded, open the notification or go to <strong className="text-zinc-300">My Files &gt; Downloads</strong>.</li>
            <li>Tap <strong className="text-zinc-300">SHEILA-GBA-EMU.apk</strong> and choose <strong className="text-zinc-300">Install</strong>.</li>
            <li>If prompted &quot;Install unknown apps&quot;, toggle <strong className="text-zinc-300">Allow from this source</strong>.</li>
          </ol>
        </div>

        {/* Direct raw URL reference */}
        <div className="text-[10px] font-mono text-zinc-400 bg-black/40 p-2 rounded-lg break-all border border-zinc-800 flex items-center justify-between gap-2">
          <span className="truncate">{directApkUrl}</span>
          <button
            onClick={handleCopyLink}
            className="text-indigo-400 hover:text-indigo-300 shrink-0 underline"
          >
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>
    </div>
  );
};
