import React, { useState, useRef, useEffect, useCallback } from 'react';
import { EmulatorSettings, TouchLayoutConfig, ScreenLayoutConfig } from '../types';
import { DEFAULT_SETTINGS } from '../utils/storage';
import {
  Sliders,
  Move,
  RotateCcw,
  Check,
  X,
  Smartphone,
  Maximize2,
  Tv,
  Gamepad,
  Sparkles,
  Layers,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

export type EditableElement = 'screen' | 'dpad' | 'actionButtons' | 'shoulderButtons' | 'systemButtons';

interface LayoutCustomizerProps {
  settings: EmulatorSettings;
  onUpdateSettings: (settings: EmulatorSettings) => void;
  onClose: () => void;
}

export const LayoutCustomizer: React.FC<LayoutCustomizerProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  // Local editable state
  const [touchLayout, setTouchLayout] = useState<TouchLayoutConfig>({
    ...settings.controls.touchLayout,
  });
  const [screenLayout, setScreenLayout] = useState<ScreenLayoutConfig>({
    scale: settings.video.screenLayout?.scale ?? 1.0,
    x: settings.video.screenLayout?.x ?? 0,
    y: settings.video.screenLayout?.y ?? 0,
  });

  const [selectedElement, setSelectedElement] = useState<EditableElement>('dpad');
  const [editorMode, setEditorMode] = useState<'visual' | 'sliders'>('visual');
  const [isDrawerCollapsed, setIsDrawerCollapsed] = useState(false);

  // Active drag tracking
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{
    startX: number;
    startY: number;
    initialElemX: number;
    initialElemY: number;
    containerWidth: number;
    containerHeight: number;
  } | null>(null);

  const containerRef = useRef<HTMLDivElement | null>(null);

  // Preset layouts
  const applyPreset = (presetName: string) => {
    if (presetName === 'default') {
      setScreenLayout({ scale: 1.0, x: 0, y: 0 });
      setTouchLayout({ ...DEFAULT_SETTINGS.controls.touchLayout });
    } else if (presetName === 'thumb-reach') {
      // Tuned specifically for large modern phones like Samsung Galaxy S24 Ultra
      setScreenLayout({ scale: 1.05, x: 0, y: -8 });
      setTouchLayout({
        ...touchLayout,
        dpad: { x: 14, y: 78, scale: 1.1 },
        actionButtons: { x: 84, y: 78, scale: 1.1 },
        shoulderButtons: { x: 4, y: 22, scale: 1.05 }, // Lowered down the sides for index/thumb reach
        systemButtons: { x: 50, y: 92, scale: 0.95 },
      });
    } else if (presetName === 'large-screen') {
      // Screen enlarged at top, controls arranged in lower half
      setScreenLayout({ scale: 1.25, x: 0, y: -16 });
      setTouchLayout({
        ...touchLayout,
        dpad: { x: 15, y: 82, scale: 1.0 },
        actionButtons: { x: 84, y: 82, scale: 1.0 },
        shoulderButtons: { x: 3, y: 35, scale: 0.95 },
        systemButtons: { x: 50, y: 94, scale: 0.9 },
      });
    } else if (presetName === 'compact') {
      setScreenLayout({ scale: 1.0, x: 0, y: 0 });
      setTouchLayout({
        ...touchLayout,
        dpad: { x: 12, y: 75, scale: 0.85 },
        actionButtons: { x: 86, y: 75, scale: 0.85 },
        shoulderButtons: { x: 3, y: 4, scale: 0.85 },
        systemButtons: { x: 50, y: 88, scale: 0.85 },
      });
    } else if (presetName === 'arcade-spread') {
      setScreenLayout({ scale: 0.95, x: 0, y: -5 });
      setTouchLayout({
        ...touchLayout,
        dpad: { x: 16, y: 70, scale: 1.25 },
        actionButtons: { x: 82, y: 70, scale: 1.25 },
        shoulderButtons: { x: 4, y: 6, scale: 1.15 },
        systemButtons: { x: 50, y: 88, scale: 1.0 },
      });
    }
  };

  // Drag handlers
  const handleDragStart = (
    element: EditableElement,
    clientX: number,
    clientY: number,
    e: React.MouseEvent | React.TouchEvent
  ) => {
    e.stopPropagation();
    setSelectedElement(element);
    setIsDragging(true);

    const container = containerRef.current || document.body;
    const rect = container.getBoundingClientRect();

    let initialX = 0;
    let initialY = 0;

    if (element === 'screen') {
      initialX = screenLayout.x;
      initialY = screenLayout.y;
    } else if (element === 'dpad') {
      initialX = touchLayout.dpad.x;
      initialY = touchLayout.dpad.y;
    } else if (element === 'actionButtons') {
      initialX = touchLayout.actionButtons.x;
      initialY = touchLayout.actionButtons.y;
    } else if (element === 'shoulderButtons') {
      initialX = touchLayout.shoulderButtons.x;
      initialY = touchLayout.shoulderButtons.y;
    } else if (element === 'systemButtons') {
      initialX = touchLayout.systemButtons.x;
      initialY = touchLayout.systemButtons.y;
    }

    dragStartRef.current = {
      startX: clientX,
      startY: clientY,
      initialElemX: initialX,
      initialElemY: initialY,
      containerWidth: rect.width,
      containerHeight: rect.height,
    };
  };

  const handlePointerMove = useCallback(
    (clientX: number, clientY: number) => {
      if (!isDragging || !dragStartRef.current) return;

      const { startX, startY, initialElemX, initialElemY, containerWidth, containerHeight } =
        dragStartRef.current;
      const deltaXPercent = ((clientX - startX) / containerWidth) * 100;
      const deltaYPercent = ((clientY - startY) / containerHeight) * 100;

      if (selectedElement === 'screen') {
        const newX = Math.max(-35, Math.min(35, Math.round(initialElemX + deltaXPercent)));
        const newY = Math.max(-35, Math.min(35, Math.round(initialElemY + deltaYPercent)));
        setScreenLayout((prev) => ({ ...prev, x: newX, y: newY }));
      } else if (selectedElement === 'dpad') {
        const newX = Math.max(5, Math.min(45, Math.round(initialElemX + deltaXPercent)));
        const newY = Math.max(20, Math.min(95, Math.round(initialElemY + deltaYPercent)));
        setTouchLayout((prev) => ({ ...prev, dpad: { ...prev.dpad, x: newX, y: newY } }));
      } else if (selectedElement === 'actionButtons') {
        const newX = Math.max(55, Math.min(95, Math.round(initialElemX + deltaXPercent)));
        const newY = Math.max(20, Math.min(95, Math.round(initialElemY + deltaYPercent)));
        setTouchLayout((prev) => ({
          ...prev,
          actionButtons: { ...prev.actionButtons, x: newX, y: newY },
        }));
      } else if (selectedElement === 'shoulderButtons') {
        const newY = Math.max(2, Math.min(50, Math.round(initialElemY + deltaYPercent)));
        setTouchLayout((prev) => ({
          ...prev,
          shoulderButtons: { ...prev.shoulderButtons, y: newY },
        }));
      } else if (selectedElement === 'systemButtons') {
        const newX = Math.max(20, Math.min(80, Math.round(initialElemX + deltaXPercent)));
        const newY = Math.max(40, Math.min(96, Math.round(initialElemY + deltaYPercent)));
        setTouchLayout((prev) => ({
          ...prev,
          systemButtons: { ...prev.systemButtons, x: newX, y: newY },
        }));
      }
    },
    [isDragging, selectedElement]
  );

  const handleDragEnd = useCallback(() => {
    setIsDragging(false);
    dragStartRef.current = null;
  }, []);

  // Global pointer event listeners during active drag
  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      handlePointerMove(e.clientX, e.clientY);
    };
    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        handlePointerMove(e.touches[0].clientX, e.touches[0].clientY);
      }
    };
    const onEnd = () => {
      handleDragEnd();
    };

    if (isDragging) {
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onEnd);
      window.addEventListener('touchmove', onTouchMove, { passive: false });
      window.addEventListener('touchend', onEnd);
    }

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onEnd);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onEnd);
    };
  }, [isDragging, handlePointerMove, handleDragEnd]);

  // Adjust Scale for the currently selected element
  const adjustSelectedScale = (delta: number) => {
    if (selectedElement === 'screen') {
      setScreenLayout((prev) => ({
        ...prev,
        scale: Math.max(0.6, Math.min(1.6, Math.round((prev.scale + delta) * 20) / 20)),
      }));
    } else if (selectedElement === 'dpad') {
      setTouchLayout((prev) => ({
        ...prev,
        dpad: {
          ...prev.dpad,
          scale: Math.max(0.6, Math.min(1.8, Math.round((prev.dpad.scale + delta) * 20) / 20)),
        },
      }));
    } else if (selectedElement === 'actionButtons') {
      setTouchLayout((prev) => ({
        ...prev,
        actionButtons: {
          ...prev.actionButtons,
          scale: Math.max(
            0.6,
            Math.min(1.8, Math.round((prev.actionButtons.scale + delta) * 20) / 20)
          ),
        },
      }));
    } else if (selectedElement === 'shoulderButtons') {
      setTouchLayout((prev) => ({
        ...prev,
        shoulderButtons: {
          ...prev.shoulderButtons,
          scale: Math.max(
            0.6,
            Math.min(1.8, Math.round((prev.shoulderButtons.scale + delta) * 20) / 20)
          ),
        },
      }));
    } else if (selectedElement === 'systemButtons') {
      setTouchLayout((prev) => ({
        ...prev,
        systemButtons: {
          ...prev.systemButtons,
          scale: Math.max(
            0.6,
            Math.min(1.8, Math.round((prev.systemButtons.scale + delta) * 20) / 20)
          ),
        },
      }));
    }
  };

  const getSelectedScale = () => {
    if (selectedElement === 'screen') return screenLayout.scale;
    if (selectedElement === 'dpad') return touchLayout.dpad.scale;
    if (selectedElement === 'actionButtons') return touchLayout.actionButtons.scale;
    if (selectedElement === 'shoulderButtons') return touchLayout.shoulderButtons.scale;
    if (selectedElement === 'systemButtons') return touchLayout.systemButtons.scale;
    return 1.0;
  };

  const handleApplyAndSave = () => {
    onUpdateSettings({
      ...settings,
      video: {
        ...settings.video,
        screenLayout,
      },
      controls: {
        ...settings.controls,
        touchLayout,
      },
    });
    onClose();
  };

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 bg-[#0b0e14]/90 backdrop-blur-md flex flex-col select-none touch-none overflow-hidden"
    >
      {/* Top Header Bar */}
      <div className="w-full bg-[#11151e] border-b border-[#202735] px-4 py-2.5 flex items-center justify-between z-30 shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-700/60 flex items-center justify-center text-indigo-400">
            <Move className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-white text-sm font-bold flex items-center gap-2">
              <span>Screen & Controls Customizer</span>
              <span className="text-[10px] bg-indigo-900/60 text-indigo-300 px-1.5 py-0.2 rounded border border-indigo-700/50">
                Live Edit
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400 hidden sm:block">
              Touch or drag elements to reposition. Use the toolbar below to scale and tune.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setEditorMode(editorMode === 'visual' ? 'sliders' : 'visual')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium border border-zinc-700 transition-colors"
          >
            {editorMode === 'visual' ? (
              <>
                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                <span className="hidden xs:inline">Sliders View</span>
              </>
            ) : (
              <>
                <Move className="w-3.5 h-3.5 text-indigo-400" />
                <span className="hidden xs:inline">Visual Drag</span>
              </>
            )}
          </button>

          <button
            onClick={() => applyPreset('default')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium transition-colors"
            title="Reset to default handheld layout"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </button>

          <button
            onClick={handleApplyAndSave}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
          >
            <Check className="w-4 h-4" />
            <span>Apply & Save</span>
          </button>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
            title="Cancel"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Visual Canvas Area */}
      <div className="flex-1 relative w-full h-full overflow-hidden flex items-center justify-center p-2">
        {/* Subtle Background Grid Guide */}
        <div
          className="absolute inset-0 opacity-15 pointer-events-none"
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.4) 1px, transparent 0)',
            backgroundSize: '24px 24px',
          }}
        />

        {/* 1. GBA SCREEN BEZEL DRAGGABLE ELEMENT */}
        <div
          onMouseDown={(e) => handleDragStart('screen', e.clientX, e.clientY, e)}
          onTouchStart={(e) =>
            handleDragStart('screen', e.touches[0].clientX, e.touches[0].clientY, e)
          }
          className={`absolute cursor-move flex flex-col items-center justify-center p-2 rounded-2xl transition-shadow ${
            selectedElement === 'screen'
              ? 'ring-2 ring-indigo-500 shadow-indigo-500/30 shadow-2xl z-20'
              : 'border-2 border-dashed border-zinc-700 hover:border-zinc-500 z-10'
          }`}
          style={{
            transform: `translate(${screenLayout.x}%, ${screenLayout.y}%) scale(${screenLayout.scale})`,
            transformOrigin: 'center center',
          }}
        >
          {/* Active Element Badge */}
          <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-indigo-600 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded-full shadow flex items-center gap-1 whitespace-nowrap pointer-events-none">
            <Tv className="w-3 h-3" />
            <span>GBA SCREEN ({(screenLayout.scale * 100).toFixed(0)}%)</span>
          </div>

          <div className="w-[320px] sm:w-[420px] h-[213px] sm:h-[280px] bg-[#0c0f16] border-2 border-[#1e2535] rounded-xl flex flex-col items-center justify-center relative overflow-hidden shadow-inner">
            <div className="w-full h-full bg-gradient-to-b from-indigo-950/30 to-purple-950/20 flex flex-col items-center justify-center p-4 text-center">
              <Tv className="w-8 h-8 text-indigo-400 mb-1" />
              <span className="text-white text-xs font-bold">GAMEPLAY SCREEN</span>
              <span className="text-zinc-400 text-[10px] mt-0.5">
                Drag to reposition • Scale: {(screenLayout.scale * 100).toFixed(0)}%
              </span>
              <span className="font-mono text-zinc-500 text-[9px] mt-1">
                Offset X: {screenLayout.x}% | Y: {screenLayout.y}%
              </span>
            </div>
          </div>
        </div>

        {/* 2. SHOULDER TRIGGER L */}
        <div
          onMouseDown={(e) => handleDragStart('shoulderButtons', e.clientX, e.clientY, e)}
          onTouchStart={(e) =>
            handleDragStart('shoulderButtons', e.touches[0].clientX, e.touches[0].clientY, e)
          }
          className={`absolute cursor-move z-20 ${
            selectedElement === 'shoulderButtons'
              ? 'ring-2 ring-indigo-500 rounded-2xl shadow-lg'
              : ''
          }`}
          style={{
            top: `${touchLayout.shoulderButtons.y}%`,
            left: `${touchLayout.shoulderButtons.x < 50 ? touchLayout.shoulderButtons.x : 3}%`,
            transform: `scale(${touchLayout.shoulderButtons.scale})`,
            transformOrigin: 'top left',
          }}
        >
          <div className="w-24 h-12 rounded-2xl bg-zinc-800/90 border border-zinc-600 text-zinc-200 font-bold text-xs flex items-center justify-center shadow-lg">
            TRIGGER L
          </div>
          {selectedElement === 'shoulderButtons' && (
            <span className="absolute -bottom-5 left-0 text-[9px] font-mono text-indigo-300 bg-indigo-950/90 px-1.5 rounded whitespace-nowrap">
              L/R {touchLayout.shoulderButtons.scale.toFixed(1)}x
            </span>
          )}
        </div>

        {/* 3. SHOULDER TRIGGER R */}
        <div
          onMouseDown={(e) => handleDragStart('shoulderButtons', e.clientX, e.clientY, e)}
          onTouchStart={(e) =>
            handleDragStart('shoulderButtons', e.touches[0].clientX, e.touches[0].clientY, e)
          }
          className={`absolute cursor-move z-20 ${
            selectedElement === 'shoulderButtons'
              ? 'ring-2 ring-indigo-500 rounded-2xl shadow-lg'
              : ''
          }`}
          style={{
            top: `${touchLayout.shoulderButtons.y}%`,
            right: `${touchLayout.shoulderButtons.x < 50 ? touchLayout.shoulderButtons.x : 3}%`,
            transform: `scale(${touchLayout.shoulderButtons.scale})`,
            transformOrigin: 'top right',
          }}
        >
          <div className="w-24 h-12 rounded-2xl bg-zinc-800/90 border border-zinc-600 text-zinc-200 font-bold text-xs flex items-center justify-center shadow-lg">
            TRIGGER R
          </div>
        </div>

        {/* 4. D-PAD CLUSTER */}
        <div
          onMouseDown={(e) => handleDragStart('dpad', e.clientX, e.clientY, e)}
          onTouchStart={(e) =>
            handleDragStart('dpad', e.touches[0].clientX, e.touches[0].clientY, e)
          }
          className={`absolute cursor-move z-20 p-2 ${
            selectedElement === 'dpad'
              ? 'ring-2 ring-indigo-500 rounded-full shadow-indigo-500/30 shadow-xl'
              : 'border border-dashed border-zinc-600/60 rounded-full'
          }`}
          style={{
            left: `${touchLayout.dpad.x}%`,
            top: `${touchLayout.dpad.y}%`,
            transform: `translate(-50%, -50%) scale(${touchLayout.dpad.scale})`,
            transformOrigin: 'center center',
          }}
        >
          <div className="relative w-36 h-36 flex items-center justify-center pointer-events-none">
            <div className="absolute w-12 h-36 bg-zinc-800 border-2 border-zinc-600 rounded-xl" />
            <div className="absolute w-36 h-12 bg-zinc-800 border-2 border-zinc-600 rounded-xl" />
            <div className="absolute w-10 h-10 rounded-full bg-zinc-900/80 border border-zinc-700 flex items-center justify-center text-zinc-400 text-[10px] font-bold">
              D-PAD
            </div>
          </div>
          {selectedElement === 'dpad' && (
            <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-[9px] font-mono font-bold text-indigo-300 bg-indigo-950/90 border border-indigo-700 px-2 py-0.5 rounded-full whitespace-nowrap shadow">
              D-PAD ({touchLayout.dpad.scale.toFixed(1)}x)
            </span>
          )}
        </div>

        {/* 5. ACTION BUTTONS (A & B) */}
        <div
          onMouseDown={(e) => handleDragStart('actionButtons', e.clientX, e.clientY, e)}
          onTouchStart={(e) =>
            handleDragStart('actionButtons', e.touches[0].clientX, e.touches[0].clientY, e)
          }
          className={`absolute cursor-move z-20 p-2 ${
            selectedElement === 'actionButtons'
              ? 'ring-2 ring-indigo-500 rounded-2xl shadow-indigo-500/30 shadow-xl'
              : 'border border-dashed border-zinc-600/60 rounded-2xl'
          }`}
          style={{
            left: `${touchLayout.actionButtons.x}%`,
            top: `${touchLayout.actionButtons.y}%`,
            transform: `translate(-50%, -50%) scale(${touchLayout.actionButtons.scale})`,
            transformOrigin: 'center center',
          }}
        >
          <div className="relative w-44 h-32 flex items-center justify-center pointer-events-none">
            {/* B Button */}
            <div className="absolute bottom-2 left-2 w-16 h-16 rounded-full bg-gradient-to-br from-rose-600 to-rose-800 border-2 border-rose-400 text-white font-black text-base flex items-center justify-center shadow-lg">
              B
            </div>
            {/* A Button */}
            <div className="absolute top-2 right-2 w-16 h-16 rounded-full bg-gradient-to-br from-emerald-600 to-emerald-800 border-2 border-emerald-400 text-white font-black text-base flex items-center justify-center shadow-lg">
              A
            </div>
          </div>
          {selectedElement === 'actionButtons' && (
            <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-[9px] font-mono font-bold text-indigo-300 bg-indigo-950/90 border border-indigo-700 px-2 py-0.5 rounded-full whitespace-nowrap shadow">
              A / B ({touchLayout.actionButtons.scale.toFixed(1)}x)
            </span>
          )}
        </div>

        {/* 6. SYSTEM BUTTONS (START & SELECT) */}
        <div
          onMouseDown={(e) => handleDragStart('systemButtons', e.clientX, e.clientY, e)}
          onTouchStart={(e) =>
            handleDragStart('systemButtons', e.touches[0].clientX, e.touches[0].clientY, e)
          }
          className={`absolute cursor-move z-20 p-1.5 ${
            selectedElement === 'systemButtons'
              ? 'ring-2 ring-indigo-500 rounded-xl shadow-lg'
              : 'border border-dashed border-zinc-600/60 rounded-xl'
          }`}
          style={{
            left: `${touchLayout.systemButtons.x}%`,
            top: `${touchLayout.systemButtons.y}%`,
            transform: `translate(-50%, -50%) scale(${touchLayout.systemButtons.scale})`,
            transformOrigin: 'center center',
          }}
        >
          <div className="flex items-center gap-3 bg-zinc-900/90 px-3 py-1.5 rounded-full border border-zinc-700 pointer-events-none shadow-md">
            <span className="w-8 h-3 rounded-full bg-zinc-700 border border-zinc-600 block" />
            <span className="text-[10px] font-mono text-zinc-300 font-bold">SELECT • START</span>
            <span className="w-8 h-3 rounded-full bg-zinc-700 border border-zinc-600 block" />
          </div>
          {selectedElement === 'systemButtons' && (
            <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[9px] font-mono text-indigo-300 bg-indigo-950/90 px-2 py-0.2 rounded whitespace-nowrap shadow">
              {touchLayout.systemButtons.scale.toFixed(1)}x
            </span>
          )}
        </div>
      </div>

      {/* Floating Bottom Drawer for Controls, Scaling & Presets */}
      <div className="w-full bg-[#10141d] border-t border-[#1f2736] z-30 shadow-2xl p-3 sm:p-4 text-white">
        {/* Toggle Collapse Bar */}
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#1b212e]">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none text-xs">
            <span className="text-zinc-400 text-[11px] font-medium mr-1 hidden sm:inline">Select Element:</span>
            {[
              { id: 'screen', label: 'Screen Display', icon: Tv },
              { id: 'dpad', label: 'D-Pad', icon: Gamepad },
              { id: 'actionButtons', label: 'A / B Buttons', icon: Sparkles },
              { id: 'shoulderButtons', label: 'Triggers (L/R)', icon: Layers },
              { id: 'systemButtons', label: 'Start / Select', icon: Sliders },
            ].map((item) => {
              const Icon = item.icon;
              const isSelected = selectedElement === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setSelectedElement(item.id as EditableElement)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-zinc-800/80 text-zinc-300 hover:bg-zinc-700'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <button
            onClick={() => setIsDrawerCollapsed(!isDrawerCollapsed)}
            className="p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white"
            title={isDrawerCollapsed ? 'Expand panel' : 'Collapse panel'}
          >
            {isDrawerCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        {!isDrawerCollapsed && (
          <div className="space-y-3">
            {/* Quick Sizing Bar for currently selected element */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#151a24] p-2.5 rounded-xl border border-[#212938]">
              <div className="flex items-center justify-between sm:justify-start gap-3">
                <span className="text-xs font-semibold text-zinc-200">
                  {selectedElement === 'screen'
                    ? 'Screen Size:'
                    : selectedElement === 'dpad'
                    ? 'D-Pad Scale:'
                    : selectedElement === 'actionButtons'
                    ? 'A/B Buttons Scale:'
                    : selectedElement === 'shoulderButtons'
                    ? 'L/R Triggers Scale:'
                    : 'Start/Select Scale:'}
                </span>
                <span className="font-mono text-indigo-400 font-bold text-xs">
                  {selectedElement === 'screen'
                    ? `${(screenLayout.scale * 100).toFixed(0)}%`
                    : `${getSelectedScale().toFixed(2)}x`}
                </span>
              </div>

              {/* Quick Scale Adjuster Buttons & Slider */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => adjustSelectedScale(-0.05)}
                  className="w-8 h-8 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-sm flex items-center justify-center border border-zinc-700 active:scale-95"
                  title="Decrease size"
                >
                  -
                </button>

                <input
                  type="range"
                  min={selectedElement === 'screen' ? 0.6 : 0.6}
                  max={selectedElement === 'screen' ? 1.6 : 1.8}
                  step="0.05"
                  value={getSelectedScale()}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (selectedElement === 'screen') {
                      setScreenLayout((prev) => ({ ...prev, scale: val }));
                    } else if (selectedElement === 'dpad') {
                      setTouchLayout((prev) => ({ ...prev, dpad: { ...prev.dpad, scale: val } }));
                    } else if (selectedElement === 'actionButtons') {
                      setTouchLayout((prev) => ({
                        ...prev,
                        actionButtons: { ...prev.actionButtons, scale: val },
                      }));
                    } else if (selectedElement === 'shoulderButtons') {
                      setTouchLayout((prev) => ({
                        ...prev,
                        shoulderButtons: { ...prev.shoulderButtons, scale: val },
                      }));
                    } else if (selectedElement === 'systemButtons') {
                      setTouchLayout((prev) => ({
                        ...prev,
                        systemButtons: { ...prev.systemButtons, scale: val },
                      }));
                    }
                  }}
                  className="w-32 sm:w-48 accent-indigo-500 cursor-pointer"
                />

                <button
                  onClick={() => adjustSelectedScale(0.05)}
                  className="w-8 h-8 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-sm flex items-center justify-center border border-zinc-700 active:scale-95"
                  title="Increase size"
                >
                  +
                </button>
              </div>

              {/* Opacity & Haptic quick switches */}
              <div className="flex items-center gap-3 pt-1 sm:pt-0 border-t sm:border-t-0 border-[#1f2636]">
                <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                  <span>Opacity:</span>
                  <span className="font-mono text-indigo-400">
                    {Math.round(touchLayout.opacity * 100)}%
                  </span>
                  <input
                    type="range"
                    min="0.2"
                    max="1.0"
                    step="0.05"
                    value={touchLayout.opacity}
                    onChange={(e) =>
                      setTouchLayout((prev) => ({ ...prev, opacity: parseFloat(e.target.value) }))
                    }
                    className="w-16 accent-indigo-500"
                  />
                </div>

                <label className="flex items-center gap-1.5 text-xs text-zinc-300 cursor-pointer">
                  <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[11px]">Haptics</span>
                  <input
                    type="checkbox"
                    checked={touchLayout.haptics}
                    onChange={(e) =>
                      setTouchLayout((prev) => ({ ...prev, haptics: e.target.checked }))
                    }
                    className="rounded accent-indigo-600 w-3.5 h-3.5"
                  />
                </label>
              </div>
            </div>

            {/* Ergonomic Presets Buttons */}
            <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pt-1">
              <span className="text-[11px] font-semibold text-zinc-400 whitespace-nowrap flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>Comfort Presets:</span>
              </span>

              {[
                {
                  id: 'thumb-reach',
                  label: 'S24 Ultra / Thumb Comfort',
                  desc: 'Lowered controls for easy thumb reach',
                },
                {
                  id: 'large-screen',
                  label: 'Big Screen Focus',
                  desc: 'Top large screen with bottom controls',
                },
                {
                  id: 'arcade-spread',
                  label: 'Arcade Wide',
                  desc: 'Spaced out larger buttons',
                },
                {
                  id: 'compact',
                  label: 'Compact Mini',
                  desc: 'Minimal smaller footprint',
                },
                {
                  id: 'default',
                  label: 'Classic GBA',
                  desc: 'Original handheld proportions',
                },
              ].map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => applyPreset(preset.id)}
                  className="px-2.5 py-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 text-[11px] whitespace-nowrap transition-colors"
                  title={preset.desc}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
