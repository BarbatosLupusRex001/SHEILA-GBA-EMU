import React, { useState, useRef } from 'react';
import { Game, SaveState, BatterySave } from '../types';
import { emulatorInstance } from '../emulator/GBAEmulator';
import {
  Save,
  Download,
  Trash2,
  Clock,
  HardDrive,
  Upload,
  AlertCircle,
  FileDown,
  CheckCircle,
  ShieldCheck,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface SavesManagerProps {
  activeGame: Game | null;
  saveStates: SaveState[];
  onSaveSlot: (slot: number) => void;
  onLoadSlot: (slot: number) => void;
  onDeleteSlot: (id: string) => void;
  onImportBatterySave: (file: File) => void;
  onExportBatterySave: () => void;
}

export const SavesManager: React.FC<SavesManagerProps> = ({
  activeGame,
  saveStates,
  onSaveSlot,
  onLoadSlot,
  onDeleteSlot,
  onImportBatterySave,
  onExportBatterySave,
}) => {
  const [toast, setToast] = useState<string | null>(null);
  const batteryFileInputRef = useRef<HTMLInputElement | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  // 10 Manual Save slots (1 through 10)
  const slots = Array.from({ length: 10 }, (_, i) => i + 1);

  const getSaveForSlot = (slot: number) => {
    if (!activeGame) return null;
    return saveStates.find((s) => s.gameId === activeGame.id && s.slot === slot) || null;
  };

  const autoSaveState = getSaveForSlot(0);

  const formatRelativeTime = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins === 1) return '1 minute ago';
    if (mins < 60) return `${mins} minutes ago`;
    const hours = Math.floor(mins / 60);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Toast */}
      {toast && (
        <div className="fixed top-20 right-6 z-50 bg-indigo-900 border border-indigo-500 text-white text-xs px-4 py-2 rounded-xl shadow-xl flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{toast}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#1f2533] pb-5">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Save className="w-6 h-6 text-indigo-400" />
            <span>Save States & Battery Saves</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Background auto-save safeguards your progress every 5 minutes and on exit. Manual slots (1–10) provide on-demand state freezing.
          </p>
        </div>

        {activeGame && (
          <div className="flex items-center gap-2 bg-[#121620] border border-[#212836] px-3 py-1.5 rounded-xl text-xs text-zinc-300">
            <span className="font-semibold text-white">{activeGame.title}</span>
            <span className="text-zinc-500">•</span>
            <span className="font-mono text-indigo-300">{activeGame.code}</span>
          </div>
        )}
      </div>

      {/* Dedicated Background Auto-Save Slot Card */}
      <div className="bg-gradient-to-r from-[#0d1726] to-[#111827] border border-emerald-500/30 rounded-2xl p-5 shadow-lg space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-950/80 border border-emerald-600/40 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Auto-Save Slot (Background Safeguard)</h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-700/60 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  EVERY 5 MIN & ON EXIT
                </span>
              </div>
              <p className="text-xs text-zinc-300 mt-0.5">
                Automatically takes snapshots in the emulator background without interrupting gameplay or pausing.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                onSaveSlot(0);
                showToast('Auto-Save snapshot updated');
              }}
              disabled={!activeGame}
              className="flex items-center gap-1.5 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 text-zinc-200 rounded-xl text-xs font-medium transition-colors cursor-pointer"
              title="Force an immediate auto-save snapshot"
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>Snapshot Now</span>
            </button>
            <button
              onClick={() => {
                onLoadSlot(0);
                showToast('Auto-Save state restored');
              }}
              disabled={!activeGame || !autoSaveState}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-xl text-xs font-semibold shadow-md transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Restore Auto-Save</span>
            </button>
          </div>
        </div>

        {/* Auto-Save Content Info */}
        {activeGame ? (
          autoSaveState ? (
            <div className="flex flex-col sm:flex-row items-center gap-4 bg-[#0a0f18]/80 border border-emerald-900/40 rounded-xl p-3">
              <div className="w-36 h-24 bg-[#06080d] rounded-lg overflow-hidden border border-zinc-800 shrink-0 relative flex items-center justify-center">
                {autoSaveState.screenshotUrl ? (
                  <img
                    src={autoSaveState.screenshotUrl}
                    alt="Auto-save state"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-zinc-600 text-xs">No preview</div>
                )}
                <span className="absolute bottom-1 right-1 bg-black/80 text-[9px] font-mono px-1.5 py-0.5 rounded text-emerald-400 border border-emerald-500/30">
                  SLOT 0
                </span>
              </div>

              <div className="flex-1 space-y-1 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-white font-semibold">Latest Snapshot:</span>
                  <span className="text-emerald-400 font-medium">
                    {formatRelativeTime(autoSaveState.timestamp)}
                  </span>
                  <span className="text-zinc-500">
                    ({new Date(autoSaveState.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })})
                  </span>
                </div>
                <div className="text-zinc-400 flex items-center gap-1 text-[11px]">
                  <span>Trigger reason:</span>
                  <span className="text-zinc-200 capitalize font-mono">
                    {autoSaveState.autoSaveReason === 'periodic'
                      ? '5-Minute Interval'
                      : autoSaveState.autoSaveReason === 'exit'
                      ? 'Game Exit'
                      : autoSaveState.autoSaveReason === 'tab_change'
                      ? 'Tab Navigation'
                      : 'Manual Trigger'}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-500">
                  This slot will automatically refresh every 5 minutes while you play, or whenever you close the game or leave the emulator.
                </p>
              </div>

              <button
                onClick={() => onDeleteSlot(autoSaveState.id)}
                className="p-2 text-zinc-500 hover:text-rose-400 transition-colors"
                title="Clear Auto-Save State"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="bg-[#0a0f18]/80 border border-zinc-800/80 rounded-xl p-3.5 text-xs text-zinc-400 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>
                  No auto-save captured yet for <strong className="text-zinc-200">{activeGame.title}</strong>. The first auto-save will trigger automatically within 5 minutes of gameplay or upon exiting the game.
                </span>
              </div>
              <button
                onClick={() => onSaveSlot(0)}
                className="px-2.5 py-1 text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg transition-colors font-medium shrink-0"
              >
                Create Now
              </button>
            </div>
          )
        ) : (
          <div className="bg-[#0a0f18]/80 border border-zinc-800/80 rounded-xl p-3.5 text-xs text-zinc-500">
            Select a game to activate background auto-saving.
          </div>
        )}
      </div>

      {/* Battery Save Management Card */}
      <div className="bg-[#11151e] border border-[#222937] rounded-2xl p-5 space-y-4 shadow-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-zinc-800 flex items-center justify-center text-amber-400">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Cartridge Battery Save (.sav)</h3>
              <p className="text-xs text-zinc-400">
                Direct SRAM / Flash memory. Compatible with hardware flashcards and other GBA emulators.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={batteryFileInputRef}
              accept=".sav,.srm"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  onImportBatterySave(e.target.files[0]);
                  showToast('Imported .sav battery save');
                }
              }}
              className="hidden"
            />
            <button
              onClick={() => batteryFileInputRef.current?.click()}
              disabled={!activeGame}
              className="flex items-center gap-1.5 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 text-zinc-200 rounded-xl text-xs font-medium transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Import .sav</span>
            </button>
            <button
              onClick={() => {
                onExportBatterySave();
                showToast('Exported battery save file');
              }}
              disabled={!activeGame}
              className="flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shadow transition-colors"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>Export .sav</span>
            </button>
          </div>
        </div>
      </div>

      {/* Save States Slots 1 to 10 */}
      <div>
        <h3 className="text-sm font-bold text-zinc-200 mb-3 flex items-center gap-2">
          <span>Manual Save State Slots (1–10)</span>
          {!activeGame && (
            <span className="text-xs text-amber-400 font-normal">
              (Load a game to save/restore state snapshots)
            </span>
          )}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {slots.map((slot) => {
            const save = getSaveForSlot(slot);
            return (
              <div
                key={slot}
                className="bg-[#121620] border border-[#212937] hover:border-[#313b4e] rounded-2xl p-3 flex flex-col justify-between space-y-3 transition-all shadow"
              >
                {/* Slot header */}
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-indigo-300 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/50">
                    SLOT {slot}
                  </span>
                  {save && (
                    <button
                      onClick={() => onDeleteSlot(save.id)}
                      className="p-1 text-zinc-500 hover:text-rose-400 transition-colors cursor-pointer"
                      title="Delete Save State"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Thumbnail Preview */}
                <div className="aspect-[3/2] bg-[#090b10] rounded-xl overflow-hidden border border-[#1c222e] flex items-center justify-center relative group">
                  {save?.screenshotUrl ? (
                    <img
                      src={save.screenshotUrl}
                      alt={`Slot ${slot}`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="text-center p-2">
                      <Save className="w-5 h-5 text-zinc-600 mx-auto mb-1" />
                      <span className="text-[10px] text-zinc-600 font-mono">EMPTY</span>
                    </div>
                  )}
                </div>

                {/* Timestamp */}
                <div className="text-[10px] text-zinc-400 flex items-center gap-1 font-mono">
                  <Clock className="w-3 h-3 text-zinc-500" />
                  <span>
                    {save ? new Date(save.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'No state'}
                  </span>
                </div>

                {/* Actions */}
                <div className="grid grid-cols-2 gap-1.5 pt-1">
                  <button
                    onClick={() => onSaveSlot(slot)}
                    disabled={!activeGame}
                    className="py-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-white rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Save className="w-3 h-3 text-indigo-400" />
                    <span>Save</span>
                  </button>

                  <button
                    onClick={() => onLoadSlot(slot)}
                    disabled={!activeGame || !save}
                    className="py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1 shadow cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>Load</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
