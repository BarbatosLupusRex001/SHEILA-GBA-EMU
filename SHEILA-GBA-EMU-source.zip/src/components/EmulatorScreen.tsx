import React, { useRef, useEffect, useState, useCallback } from 'react';
import { emulatorInstance, EmulatorStats } from '../emulator/GBAEmulator';
import { TouchControls } from './TouchControls';
import { LayoutCustomizer } from './LayoutCustomizer';
import { Game, EmulatorSettings, SaveState } from '../types';
import { getRomBlob } from '../utils/storage';
import {
  Play,
  Pause,
  RotateCcw,
  Zap,
  Camera,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Sliders,
  Gamepad,
  Save,
  Download,
  AlertCircle,
  Eye,
  EyeOff,
  Rewind,
  LogOut,
  ShieldCheck,
  Wand2,
  Power,
  PowerOff,
  ExternalLink,
} from 'lucide-react';
import { Cheat } from '../types';

interface EmulatorScreenProps {
  activeGame: Game | null;
  settings: EmulatorSettings;
  cheats?: Cheat[];
  onToggleCheat?: (id: string) => void;
  onOpenCheatsTab?: () => void;
  onUpdateSettings: (settings: EmulatorSettings) => void;
  onSaveState: (state: SaveState) => void;
  onQuickLoadRequested?: (slot?: number) => SaveState | null;
  onSelectGameTab: () => void;
}

export const EmulatorScreen: React.FC<EmulatorScreenProps> = ({
  activeGame,
  settings,
  cheats = [],
  onToggleCheat,
  onOpenCheatsTab,
  onUpdateSettings,
  onSaveState,
  onQuickLoadRequested,
  onSelectGameTab,
}) => {
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [showQuickCheats, setShowQuickCheats] = useState(false);

  const [stats, setStats] = useState<EmulatorStats>({
    fps: 60,
    speedMultiplier: 1,
    status: 'idle',
    gameTitle: activeGame?.title || '',
  });

  const [playerUrl, setPlayerUrl] = useState<string | null>(null);
  const [blobUrlToClean, setBlobUrlToClean] = useState<string | null>(null);
  const [isFastForward, setIsFastForward] = useState(false);
  const [fastForwardSpeed, setFastForwardSpeed] = useState<2 | 3 | 4 | 8 | 16>(
    settings.emulation.fastForwardSpeed || 2
  );
  const [isMuted, setIsMuted] = useState(settings.audio.muted);
  const [showTouchControls, setShowTouchControls] = useState(true);
  const [showLayoutEditor, setShowLayoutEditor] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [gamepadConnected, setGamepadConnected] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<number>(1);
  const [lastAutoSaveTime, setLastAutoSaveTime] = useState<number | null>(null);

  // Active game cheats for in-game HUD popover
  const activeGameCheats = cheats.filter(
    (c) => (activeGame && c.gameId === activeGame.id) || c.gameId === 'global'
  );
  const activeCheatsCount = activeGameCheats.filter((c) => c.enabled).length;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // 5-Minute Periodic Auto-Save Timer
  useEffect(() => {
    if (!activeGame || stats.status !== 'running') return;
    if (settings.general.autoSaveEnabled === false) return;

    const intervalMinutes = settings.general.autoSaveIntervalMinutes || 5;
    const intervalMs = intervalMinutes * 60 * 1000;

    const timer = setInterval(() => {
      console.log(`[Auto-Save] Triggering ${intervalMinutes}-minute background save for ${activeGame.title}`);
      emulatorInstance.saveState(0, true, 'periodic');
    }, intervalMs);

    return () => clearInterval(timer);
  }, [activeGame?.id, stats.status, settings.general.autoSaveEnabled, settings.general.autoSaveIntervalMinutes]);

  // Auto-Save upon game exit / window unload
  useEffect(() => {
    const handleExit = () => {
      if (activeGame && settings.general.autoSaveOnExit !== false) {
        emulatorInstance.saveState(0, true, 'exit');
      }
    };

    window.addEventListener('beforeunload', handleExit);
    window.addEventListener('pagehide', handleExit);

    return () => {
      window.removeEventListener('beforeunload', handleExit);
      window.removeEventListener('pagehide', handleExit);
      handleExit();
    };
  }, [activeGame?.id, settings.general.autoSaveOnExit]);

  // Build the player URL for activeGame
  useEffect(() => {
    let active = true;
    let createdUrl: string | null = null;

    const setupRom = async () => {
      if (!activeGame) {
        setPlayerUrl(null);
        return;
      }

      const volumeVal = isMuted ? 0 : settings.audio.volume / 100;

      if (activeGame.homebrewPath) {
        const url = `/player.html?rom=${encodeURIComponent(activeGame.homebrewPath)}&title=${encodeURIComponent(
          activeGame.title
        )}&volume=${volumeVal}&start=true`;
        if (active) setPlayerUrl(url);
      } else {
        const buffer = await getRomBlob(activeGame.id);
        if (!active) return;
        if (buffer) {
          const blob = new Blob([buffer], { type: 'application/octet-stream' });
          createdUrl = URL.createObjectURL(blob);
          setBlobUrlToClean(createdUrl);
          const url = `/player.html?rom=${encodeURIComponent(createdUrl)}&title=${encodeURIComponent(
            activeGame.title
          )}&volume=${volumeVal}&start=true`;
          setPlayerUrl(url);
        } else {
          showToast('Could not load ROM binary from local storage');
        }
      }
    };

    setupRom();

    return () => {
      active = false;
      if (createdUrl) {
        URL.revokeObjectURL(createdUrl);
      }
    };
  }, [activeGame?.id]);

  // Clean up blob URL when unmounting
  useEffect(() => {
    return () => {
      if (blobUrlToClean) {
        URL.revokeObjectURL(blobUrlToClean);
      }
    };
  }, [blobUrlToClean]);

  // Connect emulatorInstance to player iframe
  useEffect(() => {
    if (iframeRef.current) {
      emulatorInstance.setPlayerIframe(iframeRef.current);
    }
  }, [playerUrl]);

  // Listen for messages from player.html
  useEffect(() => {
    const handlePlayerMessage = (event: MessageEvent) => {
      if (!event.data || event.data.source !== 'SHEILA_GBA') return;
      const { type, payload } = event.data;

      switch (type) {
        case 'GAME_STARTED':
          setStats((prev) => ({ ...prev, status: 'running', gameTitle: payload?.title || '' }));
          showToast(`Now playing: ${payload?.title || activeGame?.title || 'Game'}`);
          break;

        case 'SAVE_STATE_RESULT':
          if (activeGame && payload) {
            const slotNum = payload.slot !== undefined && payload.slot !== null ? Number(payload.slot) : selectedSlot;
            const isAuto = Boolean(payload.isAutoSave || slotNum === 0);
            const saveObj: SaveState = {
              id: `save-${activeGame.id}-slot-${slotNum}`,
              gameId: activeGame.id,
              slot: slotNum,
              timestamp: payload.timestamp || Date.now(),
              screenshotUrl: payload.screenshot || '',
              stateData: payload.state ? JSON.stringify(payload.state) : undefined,
              isAutoSave: isAuto,
              autoSaveReason: payload.reason || (isAuto ? 'periodic' : 'manual'),
            };
            onSaveState(saveObj);
            if (isAuto) {
              setLastAutoSaveTime(Date.now());
              showToast(
                payload.reason === 'exit'
                  ? 'Auto-saved before game exit'
                  : 'Auto-saved progress (5 min periodic)'
              );
            } else {
              showToast(`Quick Save created in Slot ${slotNum}`);
            }
          }
          break;

        case 'LOAD_STATE_SUCCESS':
          showToast(`Quick Load: Slot ${payload?.slot || selectedSlot} restored`);
          break;

        case 'SCREENSHOT_RESULT':
          if (payload?.screenshot) {
            const a = document.createElement('a');
            a.href = payload.screenshot;
            a.download = `${activeGame?.title || 'GBA'}_screenshot_${Date.now()}.png`;
            a.click();
            showToast('Screenshot downloaded');
          }
          break;
      }
    };

    window.addEventListener('message', handlePlayerMessage);
    return () => window.removeEventListener('message', handlePlayerMessage);
  }, [activeGame, selectedSlot, onSaveState]);

  // Setup core listeners
  useEffect(() => {
    emulatorInstance.onStats((newStats) => {
      setStats(newStats);
    });

    emulatorInstance.onError((err) => {
      showToast(`Emulator: ${err}`);
    });

    return () => {
      emulatorInstance.stop();
    };
  }, []);

  // Update volume / settings
  useEffect(() => {
    emulatorInstance.setVolume(settings.audio.volume);
    emulatorInstance.setMuted(isMuted);
    emulatorInstance.setFrameSkip(settings.emulation.frameSkip);
  }, [settings.audio.volume, isMuted, settings.emulation.frameSkip]);

  // Handle Gamepad polling
  useEffect(() => {
    let animationId: number;

    const pollGamepads = () => {
      if (typeof navigator !== 'undefined' && navigator.getGamepads) {
        const gamepads = navigator.getGamepads();
        const gp = gamepads[0];
        if (gp && gp.connected) {
          if (!gamepadConnected) setGamepadConnected(true);

          // Map buttons: 0=A, 1=B, 8=SELECT, 9=START, 4=L, 5=R, 12=UP, 13=DOWN, 14=LEFT, 15=RIGHT
          if (gp.buttons[0]?.pressed) emulatorInstance.pressKey('A'); else emulatorInstance.releaseKey('A');
          if (gp.buttons[1]?.pressed) emulatorInstance.pressKey('B'); else emulatorInstance.releaseKey('B');
          if (gp.buttons[8]?.pressed) emulatorInstance.pressKey('SELECT'); else emulatorInstance.releaseKey('SELECT');
          if (gp.buttons[9]?.pressed) emulatorInstance.pressKey('START'); else emulatorInstance.releaseKey('START');
          if (gp.buttons[4]?.pressed) emulatorInstance.pressKey('L'); else emulatorInstance.releaseKey('L');
          if (gp.buttons[5]?.pressed) emulatorInstance.pressKey('R'); else emulatorInstance.releaseKey('R');
          if (gp.buttons[12]?.pressed) emulatorInstance.pressKey('UP'); else emulatorInstance.releaseKey('UP');
          if (gp.buttons[13]?.pressed) emulatorInstance.pressKey('DOWN'); else emulatorInstance.releaseKey('DOWN');
          if (gp.buttons[14]?.pressed) emulatorInstance.pressKey('LEFT'); else emulatorInstance.releaseKey('LEFT');
          if (gp.buttons[15]?.pressed) emulatorInstance.pressKey('RIGHT'); else emulatorInstance.releaseKey('RIGHT');

          // Axes
          const x = gp.axes[0] || 0;
          const y = gp.axes[1] || 0;
          if (x < -0.5) emulatorInstance.pressKey('LEFT');
          if (x > 0.5) emulatorInstance.pressKey('RIGHT');
          if (y < -0.5) emulatorInstance.pressKey('UP');
          if (y > 0.5) emulatorInstance.pressKey('DOWN');
        } else {
          if (gamepadConnected) setGamepadConnected(false);
        }
      }
      animationId = requestAnimationFrame(pollGamepads);
    };

    animationId = requestAnimationFrame(pollGamepads);
    return () => cancelAnimationFrame(animationId);
  }, [gamepadConnected]);

  // Keyboard controls listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid capturing when in input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      switch (e.code) {
        case 'KeyZ':
        case 'KeyK':
          emulatorInstance.pressKey('A');
          break;
        case 'KeyX':
        case 'KeyJ':
          emulatorInstance.pressKey('B');
          break;
        case 'KeyA':
        case 'KeyQ':
          emulatorInstance.pressKey('L');
          break;
        case 'KeyS':
        case 'KeyE':
          emulatorInstance.pressKey('R');
          break;
        case 'Enter':
          emulatorInstance.pressKey('START');
          break;
        case 'ShiftRight':
        case 'ShiftLeft':
          emulatorInstance.pressKey('SELECT');
          break;
        case 'ArrowUp':
          emulatorInstance.pressKey('UP');
          break;
        case 'ArrowDown':
          emulatorInstance.pressKey('DOWN');
          break;
        case 'ArrowLeft':
          emulatorInstance.pressKey('LEFT');
          break;
        case 'ArrowRight':
          emulatorInstance.pressKey('RIGHT');
          break;
        case 'Space':
          e.preventDefault();
          toggleFastForward();
          break;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      switch (e.code) {
        case 'KeyZ':
        case 'KeyK':
          emulatorInstance.releaseKey('A');
          break;
        case 'KeyX':
        case 'KeyJ':
          emulatorInstance.releaseKey('B');
          break;
        case 'KeyA':
        case 'KeyQ':
          emulatorInstance.releaseKey('L');
          break;
        case 'KeyS':
        case 'KeyE':
          emulatorInstance.releaseKey('R');
          break;
        case 'Enter':
          emulatorInstance.releaseKey('START');
          break;
        case 'ShiftRight':
        case 'ShiftLeft':
          emulatorInstance.releaseKey('SELECT');
          break;
        case 'ArrowUp':
          emulatorInstance.releaseKey('UP');
          break;
        case 'ArrowDown':
          emulatorInstance.releaseKey('DOWN');
          break;
        case 'ArrowLeft':
          emulatorInstance.releaseKey('LEFT');
          break;
        case 'ArrowRight':
          emulatorInstance.releaseKey('RIGHT');
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const toggleFastForward = () => {
    const nextState = !isFastForward;
    setIsFastForward(nextState);
    const speed = nextState ? fastForwardSpeed : 1;
    emulatorInstance.setFastForward(nextState, speed);
    showToast(nextState ? `Turbo ${speed}x Active` : 'Normal Speed (1x)');
  };

  const cycleSpeed = () => {
    const speeds: (2 | 3 | 4 | 8 | 16)[] = [2, 4, 8, 16];
    const nextIdx = (speeds.indexOf(fastForwardSpeed) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    setFastForwardSpeed(nextSpeed);
    if (isFastForward) {
      emulatorInstance.setFastForward(true, nextSpeed);
      showToast(`Turbo Speed: ${nextSpeed}x`);
    } else {
      showToast(`Turbo Preset set to ${nextSpeed}x (Press Space to engage)`);
    }
  };

  const handlePauseResume = () => {
    if (stats.status === 'running') {
      emulatorInstance.pause();
      setStats((prev) => ({ ...prev, status: 'paused' }));
      showToast('Emulation Paused');
    } else {
      emulatorInstance.resume();
      setStats((prev) => ({ ...prev, status: 'running' }));
      showToast('Emulation Resumed');
    }
  };

  const handleReset = () => {
    emulatorInstance.reset();
    showToast('Game Reset');
  };

  const handleRewind = () => {
    emulatorInstance.rewind();
    showToast('Rewinding 5 seconds...');
  };

  const handleQuickSave = () => {
    if (!activeGame) {
      showToast('No game loaded to save');
      return;
    }
    emulatorInstance.saveState(selectedSlot, selectedSlot === 0, selectedSlot === 0 ? 'manual_autosave' : 'manual');
  };

  const handleQuickLoad = () => {
    if (!onQuickLoadRequested) return;
    const saveState = onQuickLoadRequested(selectedSlot);
    if (saveState && saveState.stateData) {
      try {
        const parsed = JSON.parse(saveState.stateData);
        emulatorInstance.loadState(saveState.slot, parsed);
        showToast(`Restored Slot ${saveState.slot === 0 ? '0 (Auto-Save)' : saveState.slot}`);
      } catch (err) {
        showToast('Error parsing save state data');
      }
    } else {
      showToast(`No Save State found in Slot ${selectedSlot === 0 ? '0 (Auto-Save)' : selectedSlot}`);
    }
  };

  const handleExitGame = () => {
    if (activeGame && settings.general.autoSaveOnExit !== false) {
      emulatorInstance.saveState(0, true, 'exit');
      showToast('Game auto-saved! Returning to library...');
      setTimeout(() => {
        onSelectGameTab();
      }, 350);
    } else {
      onSelectGameTab();
    }
  };

  const handleScreenshot = () => {
    emulatorInstance.takeScreenshot();
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Video aspect ratio styling
  const getAspectRatioClasses = () => {
    switch (settings.video.aspectRatio) {
      case '16:9':
        return 'aspect-video';
      case 'fill':
        return 'w-full h-full';
      case '3:2':
      default:
        return 'aspect-[3/2]';
    }
  };

  const getFilterClasses = () => {
    switch (settings.video.filter) {
      case 'scanlines':
        return 'after:absolute after:inset-0 after:bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.35)_50%)] after:bg-[length:100%_4px] after:pointer-events-none';
      case 'lcd':
        return 'after:absolute after:inset-0 after:bg-[radial-gradient(#000000_1px,transparent_1px)] after:bg-[length:3px_3px] after:pointer-events-none after:opacity-40';
      default:
        return '';
    }
  };

  return (
    <div
      ref={containerRef}
      className="flex flex-col items-center justify-between w-full h-[calc(100vh-5rem)] max-h-[920px] bg-[#090b10] relative select-none p-2 sm:p-4 overflow-hidden"
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-indigo-950/90 border border-indigo-500/50 text-indigo-100 text-xs font-semibold px-4 py-2 rounded-full shadow-2xl backdrop-blur-md flex items-center gap-2">
          <AlertCircle className="w-3.5 h-3.5 text-indigo-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Control HUD Bar (Responsive & clean spacing) */}
      <div className="w-full max-w-4xl flex items-center justify-between gap-1 sm:gap-2 bg-[#121620] border border-[#212938] rounded-xl px-2.5 sm:px-3 py-1.5 sm:py-2 z-30 shadow-md overflow-x-auto scrollbar-none">
        {/* Left: Playback controls */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <button
            onClick={handlePauseResume}
            className={`p-2 rounded-lg transition-colors cursor-pointer ${
              stats.status === 'running'
                ? 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
            title={stats.status === 'running' ? 'Pause' : 'Resume'}
          >
            {stats.status === 'running' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>

          <button
            onClick={handleReset}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors cursor-pointer"
            title="Reset Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={handleRewind}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-300 transition-colors cursor-pointer"
            title="Rewind (5s)"
          >
            <Rewind className="w-4 h-4" />
          </button>

          <button
            onClick={toggleFastForward}
            className={`p-2 rounded-lg transition-all flex items-center gap-1 text-xs font-mono font-bold cursor-pointer ${
              isFastForward
                ? 'bg-amber-600 text-white shadow-lg ring-1 ring-amber-400'
                : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
            }`}
            title={`Fast Forward (${fastForwardSpeed}x). Click to toggle.`}
          >
            <Zap className="w-4 h-4" />
            <span className="text-[11px]">{fastForwardSpeed}x</span>
          </button>

          <button
            onClick={cycleSpeed}
            className="px-1.5 py-1 text-[10px] rounded bg-zinc-800/80 hover:bg-zinc-700 text-zinc-400 hover:text-zinc-200 cursor-pointer font-mono"
            title="Cycle Fast Forward Multiplier (2x, 4x, 8x, 16x)"
          >
            Speed
          </button>
        </div>

        {/* Center: Save State Slots & Quick Actions */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <div
            className="hidden sm:flex items-center gap-1.5 px-2 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[11px] font-mono text-zinc-300"
            title="Auto-Save active: creates snapshots in background every 5 minutes and upon game exit"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-emerald-400 font-semibold">Auto-Save</span>
            <span className="text-zinc-500">5m</span>
          </div>

          <select
            value={selectedSlot}
            onChange={(e) => setSelectedSlot(Number(e.target.value))}
            className="bg-zinc-800 border border-zinc-700 text-zinc-200 text-xs rounded-lg px-2 py-1.5 cursor-pointer focus:outline-none"
            title="Select Save State Slot"
          >
            <option value={0}>Slot 0 (Auto-Save)</option>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((slot) => (
              <option key={slot} value={slot}>
                Slot {slot}
              </option>
            ))}
          </select>

          <button
            onClick={handleQuickSave}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors cursor-pointer"
            title={`Save State to Slot ${selectedSlot === 0 ? '0 (Auto-Save)' : selectedSlot}`}
          >
            <Save className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden md:inline">Save</span>
          </button>

          <button
            onClick={handleQuickLoad}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors cursor-pointer"
            title={`Load State from Slot ${selectedSlot === 0 ? '0 (Auto-Save)' : selectedSlot}`}
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">Load</span>
          </button>

          <button
            onClick={handleScreenshot}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors cursor-pointer"
            title="Capture Screenshot"
          >
            <Camera className="w-4 h-4" />
          </button>

          {/* Quick Cheats In-Game Button & Popover */}
          <div className="relative">
            <button
              onClick={() => setShowQuickCheats(!showQuickCheats)}
              className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeCheatsCount > 0
                  ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
              }`}
              title="Quick Cheats (Toggle in-game cheats on/off without leaving)"
            >
              <Wand2 className="w-3.5 h-3.5 text-indigo-300" />
              <span className="hidden sm:inline">Cheats</span>
              {activeCheatsCount > 0 ? (
                <span className="w-4 h-4 rounded-full bg-emerald-400 text-zinc-950 text-[10px] font-bold flex items-center justify-center">
                  {activeCheatsCount}
                </span>
              ) : (
                <span className="text-[10px] text-zinc-400 font-mono">
                  {activeGameCheats.length}
                </span>
              )}
            </button>

            {/* Quick Cheats Popover Drawer */}
            {showQuickCheats && (
              <div className="absolute top-full left-0 sm:left-auto sm:right-0 mt-2 w-72 sm:w-80 bg-[#121620] border border-[#263042] rounded-2xl p-3.5 shadow-2xl z-50 text-white space-y-3">
                <div className="flex items-center justify-between border-b border-[#212734] pb-2">
                  <div className="flex items-center gap-1.5">
                    <Wand2 className="w-4 h-4 text-indigo-400" />
                    <span className="font-bold text-xs">Quick Cheats</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800">
                    {activeCheatsCount} Active
                  </span>
                </div>

                <div className="max-h-56 overflow-y-auto space-y-2 pr-1">
                  {activeGameCheats.map((cheat) => (
                    <div
                      key={cheat.id}
                      className="flex items-center justify-between p-2 rounded-xl bg-[#0b0e15] border border-[#1b2230] text-xs gap-2"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-zinc-200 truncate">{cheat.name}</p>
                        <span className="text-[10px] font-mono text-zinc-400">{cheat.format}</span>
                      </div>
                      <button
                        onClick={() => {
                          if (onToggleCheat) onToggleCheat(cheat.id);
                          showToast(
                            cheat.enabled
                              ? `Deactivated: ${cheat.name}`
                              : `Activated: ${cheat.name}`
                          );
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer shrink-0 ${
                          cheat.enabled
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                            : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-400'
                        }`}
                      >
                        {cheat.enabled ? (
                          <>
                            <Power className="w-3 h-3" />
                            <span>ON</span>
                          </>
                        ) : (
                          <>
                            <PowerOff className="w-3 h-3" />
                            <span>OFF</span>
                          </>
                        )}
                      </button>
                    </div>
                  ))}

                  {activeGameCheats.length === 0 && (
                    <p className="text-center py-4 text-xs text-zinc-500">
                      No cheats added for this game yet.
                    </p>
                  )}
                </div>

                <div className="pt-1 border-t border-[#1f2635] flex items-center justify-between text-xs">
                  <button
                    onClick={() => {
                      setShowQuickCheats(false);
                      if (onOpenCheatsTab) onOpenCheatsTab();
                    }}
                    className="text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 transition-colors"
                  >
                    <span>Open Full Cheat Engine & Presets</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => setShowQuickCheats(false)}
                    className="text-zinc-500 hover:text-zinc-300 text-[11px]"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Audio, Fullscreen & Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {gamepadConnected && (
            <div
              className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-1 rounded-md"
              title="Physical Gamepad Connected"
            >
              <Gamepad className="w-3.5 h-3.5" />
              <span className="hidden lg:inline text-[10px]">PAD 1</span>
            </div>
          )}

          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors cursor-pointer"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setShowTouchControls(!showTouchControls)}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors cursor-pointer"
            title={showTouchControls ? 'Hide Touch Controls' : 'Show Touch Controls'}
          >
            {showTouchControls ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setShowLayoutEditor(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-700/60 text-indigo-300 transition-colors text-xs font-semibold shadow-sm cursor-pointer"
            title="Customize Screen & Controls Layout"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Layout</span>
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors cursor-pointer"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          <button
            onClick={handleExitGame}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-rose-950/60 border border-transparent hover:border-rose-800/60 text-zinc-300 hover:text-rose-300 transition-colors cursor-pointer"
            title="Auto-Save & Exit Game"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Gameplay Screen Area */}
      <div className="flex-1 w-full max-w-4xl flex items-center justify-center relative my-2 overflow-hidden">
        {/* Bezel Container with Dynamic Position & Scale */}
        <div
          className={`relative max-w-full max-h-full flex items-center justify-center p-2 rounded-2xl bg-[#0f131a] border-2 border-[#202735] shadow-2xl ${getFilterClasses()} transition-transform duration-100`}
          style={{
            transform: `translate(${settings.video.screenLayout?.x || 0}%, ${settings.video.screenLayout?.y || 0}%) scale(${settings.video.screenLayout?.scale || 1.0})`,
            transformOrigin: 'center center',
          }}
        >
          {/* WebAssembly mGBA Iframe Player */}
          {playerUrl ? (
            <iframe
              ref={iframeRef}
              src={playerUrl}
              className={`w-full max-w-[680px] max-h-[453px] bg-black rounded-lg shadow-inner border-0 ${getAspectRatioClasses()} ${
                settings.video.scaling === 'pixelated' ? 'image-render-pixelated' : ''
              }`}
              allow="autoplay; gamepad"
              title={activeGame?.title || 'SHEILA GBA Player'}
              onLoad={() => {
                if (iframeRef.current) {
                  emulatorInstance.setPlayerIframe(iframeRef.current);
                }
              }}
            />
          ) : (
            /* No Game Empty State */
            <div className="w-[320px] sm:w-[480px] aspect-[3/2] bg-[#0c0e14]/90 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center p-6 text-center space-y-3">
              <div className="w-12 h-12 rounded-xl bg-zinc-800 border border-zinc-700 flex items-center justify-center text-indigo-400">
                <Gamepad className="w-6 h-6" />
              </div>
              <h3 className="text-white font-bold text-base">No GBA Game Loaded</h3>
              <p className="text-zinc-400 text-xs max-w-xs">
                Select a game from the Games Library or import any .gba or .zip ROM file to begin playing.
              </p>
              <button
                onClick={onSelectGameTab}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-lg transition-colors cursor-pointer"
              >
                Browse Games Library
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Touch Controls Overlay placed at container level for full edge-to-edge touch space */}
      <TouchControls layout={settings.controls.touchLayout} visible={showTouchControls} />

      {/* Keyboard Shortcuts Helper Bar (Hidden on compact mobile screens to keep view clean) */}
      <div className="w-full max-w-4xl hidden sm:flex items-center justify-between text-[11px] text-zinc-400 bg-[#0e1118] border border-[#1b212c] px-3 py-1.5 rounded-lg z-20">
        <div className="flex items-center gap-3 overflow-x-auto scrollbar-none">
          <span className="font-semibold text-zinc-300">Controls:</span>
          <span><strong className="text-zinc-200">Z/K</strong>: A</span>
          <span><strong className="text-zinc-200">X/J</strong>: B</span>
          <span><strong className="text-zinc-200">A/Q</strong>: L</span>
          <span><strong className="text-zinc-200">S/E</strong>: R</span>
          <span><strong className="text-zinc-200">Enter</strong>: Start</span>
          <span><strong className="text-zinc-200">Shift</strong>: Select</span>
          <span><strong className="text-zinc-200">Space</strong>: Fast-Forward</span>
        </div>
        <div className="hidden sm:flex items-center gap-1 font-mono text-zinc-400 text-[10px]">
          <span className="text-emerald-400 font-semibold">● mGBA Core Active</span>
        </div>
      </div>

      {/* Full Interactive Layout & Screen Customizer */}
      {showLayoutEditor && (
        <LayoutCustomizer
          settings={settings}
          onUpdateSettings={onUpdateSettings}
          onClose={() => setShowLayoutEditor(false)}
        />
      )}
    </div>
  );
};
